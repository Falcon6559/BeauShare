"""Twitch chat: IRC-over-TLS connection, emote loading, and the chat view used in the app."""
import collections
import queue
import random
import socket
import ssl
import time

from PySide6.QtCore import QObject, Qt, QThread, QTimer, QUrl, Signal
from PySide6.QtGui import QPixmap, QTextDocument
from PySide6.QtNetwork import QNetworkAccessManager, QNetworkRequest
from PySide6.QtWidgets import (QCheckBox, QHBoxLayout, QLineEdit, QPushButton, QTextBrowser, QVBoxLayout, QWidget)

from ircparse import EMOTE_URL, make_message, message_html, parse_irc
from theme import LINE, PANEL, label


class TwitchChat(QThread):
    raw = Signal(dict)
    status = Signal(str)

    def __init__(self, channel, login=None, token=None):
        super().__init__()
        self.channel, self.login, self.token = channel.lower().lstrip("#"), login, token
        self._stop, self.out = False, queue.Queue()

    def stop(self):
        self._stop = True

    def say(self, text):
        self.out.put(text)

    def run(self):
        backoff = 1
        while not self._stop:
            try:
                self.status.emit("Connecting…")
                raw = socket.create_connection(("irc.chat.twitch.tv", 6697), timeout=10)
                sock = ssl.create_default_context().wrap_socket(raw, server_hostname="irc.chat.twitch.tv")
                sock.settimeout(0.5)
                send = lambda s: sock.sendall((s + "\r\n").encode("utf-8"))
                send("CAP REQ :twitch.tv/tags twitch.tv/commands")
                send("PASS " + (f"oauth:{self.token}" if self.token else "SCHMOOPIIE"))
                send("NICK " + (self.login or f"justinfan{random.randint(10000, 99999)}"))
                send(f"JOIN #{self.channel}")
                buf, backoff = "", 1
                while not self._stop:
                    while not self.out.empty():
                        send(f"PRIVMSG #{self.channel} :{self.out.get()}")
                    try:
                        data = sock.recv(4096)
                    except socket.timeout:
                        continue
                    if not data:
                        break
                    buf += data.decode("utf-8", "replace")
                    while "\r\n" in buf:
                        line, buf = buf.split("\r\n", 1)
                        self.handle(line, send)
                sock.close()
            except Exception as e:
                self.status.emit(f"Chat error: {e}")
            if self._stop:
                break
            self.status.emit("Reconnecting…")
            for _ in range(backoff * 5):
                if self._stop:
                    return
                time.sleep(0.2)
            backoff = min(30, backoff * 2)

    def handle(self, line, send):
        tags, prefix, cmd, params, trailing = parse_irc(line)
        if cmd == "PING":
            send(f"PONG :{trailing or 'tmi.twitch.tv'}")
        elif cmd == "ROOMSTATE":
            self.status.emit(f"Connected to #{self.channel}")
        elif cmd == "NOTICE" and "authentication failed" in trailing.lower():
            self.status.emit("Sign-in expired. Sign in to Twitch again.")
        elif cmd in ("PRIVMSG", "USERNOTICE"):
            msg = make_message(tags, prefix, cmd, trailing)
            if msg:
                self.raw.emit(msg)


class ChatModel(QObject):
    """One shared chat feed; the chat view, pop-out window and on-stream panel all read from it."""
    message = Signal(dict)
    status = Signal(str)

    def __init__(self):
        super().__init__()
        self.nam = QNetworkAccessManager(self)
        self.pix, self.pending, self.failed = {}, set(), set()
        self.queue, self.recent = collections.deque(), collections.deque(maxlen=60)
        self.thread, self.login, self.connected, self.old = None, None, False, []

    def connect_chat(self, channel, login=None, token=None):
        self.disconnect_chat()
        if not channel.strip():
            return
        self.login = login if token else None
        self.thread = TwitchChat(channel, login if token else None, token)
        self.thread.raw.connect(self.ingest)
        self.thread.status.connect(self._status)
        self.thread.start()

    def _status(self, s):
        self.connected = s.startswith("Connected")
        self.status.emit(s)

    def disconnect_chat(self):
        if self.thread:
            t = self.thread
            t.stop()
            t.raw.disconnect()
            t.status.disconnect()
            self.old.append(t)  # keep it alive until it has finished shutting down
            t.finished.connect(lambda t=t: self.old.remove(t) if t in self.old else None)
            self.thread = None
        self.connected = False
        self.status.emit("Not connected")

    def can_send(self):
        return bool(self.thread and self.login and self.connected)

    def send(self, text):
        if self.can_send() and text.strip():
            self.thread.say(text.strip())
            self.ingest({"system": False, "name": self.login, "color": "#B3A6FF", "badges": [], "emotes": [],
                         "ids": set(), "text": text.strip(), "action": False})  # Twitch doesn't echo your own lines

    def ingest(self, msg):
        need = [i for i in msg["ids"] if i not in self.pix and i not in self.failed]
        for i in need:
            self._fetch(i)
        self.queue.append(msg)
        if need:
            QTimer.singleShot(4000, self._timeout)
        self._drain()

    def _fetch(self, eid):
        if eid in self.pending:
            return
        self.pending.add(eid)
        reply = self.nam.get(QNetworkRequest(QUrl(EMOTE_URL.format(eid))))
        reply.finished.connect(lambda r=reply, i=eid: self._got(i, r))

    def _got(self, eid, reply):
        pm = QPixmap()
        if pm.loadFromData(reply.readAll()):
            self.pix[eid] = pm
        else:
            self.failed.add(eid)
        self.pending.discard(eid)
        reply.deleteLater()
        self._drain()

    def _timeout(self):
        self.failed.update(self.pending)
        self._drain()

    def _drain(self):  # keep chat order: wait for a message's emotes before showing the ones after it
        while self.queue and all(i in self.pix or i in self.failed for i in self.queue[0]["ids"]):
            msg = self.queue.popleft()
            self.recent.append(msg)
            self.message.emit(msg)


class ChatView(QWidget):
    def __init__(self, main, model, compact=False):
        super().__init__()
        self.m, self.model, self.added = main, model, set()
        lay = QVBoxLayout(self)
        lay.setContentsMargins(0, 0, 0, 0)
        lay.setSpacing(8)
        self.status = label(model.thread and "Connected" or "Not connected", "Muted")
        if not compact:
            row = QHBoxLayout()
            self.channel = QLineEdit(main.s["twitch_channel"] or main.twitch.login)
            self.channel.setPlaceholderText("Twitch channel")
            self.conn = QPushButton("Connect")
            self.conn.clicked.connect(self.toggle_connection)
            pop = QPushButton("Pop out")
            pop.clicked.connect(self.pop_out)
            row.addWidget(self.channel, 1)
            row.addWidget(self.conn)
            row.addWidget(pop)
            lay.addLayout(row)
            lay.addWidget(self.status)
        self.view = QTextBrowser()
        self.view.setOpenExternalLinks(True)
        self.view.document().setMaximumBlockCount(400)
        self.view.setStyleSheet(f"QTextBrowser{{background:{PANEL};border:1px solid {LINE};"
                                f"border-radius:8px;padding:6px;font-size:11pt;}}")
        lay.addWidget(self.view, 1)
        send = QHBoxLayout()
        self.box = QLineEdit()
        self.box.setPlaceholderText("Sign in to Twitch to chat")
        self.box.returnPressed.connect(self.send)
        self.send_btn = QPushButton("Send")
        self.send_btn.clicked.connect(self.send)
        send.addWidget(self.box, 1)
        send.addWidget(self.send_btn)
        lay.addLayout(send)
        self.compact = compact
        model.message.connect(self.on_message)
        model.status.connect(self.on_status)
        for m in model.recent:
            self.on_message(m)
        self.refresh_input()

    def refresh_input(self):
        ok = self.model.can_send()
        self.box.setEnabled(ok)
        self.send_btn.setEnabled(ok)
        self.box.setPlaceholderText("Send a message" if ok else "Sign in to Twitch and connect to chat")

    def on_status(self, s):
        self.status.setText(s)
        if not self.compact:
            self.conn.setText("Disconnect" if self.model.thread else "Connect")
        self.refresh_input()

    def on_message(self, msg):
        doc = self.view.document()
        for eid in msg["ids"]:
            if eid in self.model.pix and eid not in self.added:
                doc.addResource(QTextDocument.ImageResource, QUrl(f"emote:{eid}"), self.model.pix[eid])
                self.added.add(eid)
        self.view.append(message_html(msg))

    def toggle_connection(self):
        if self.model.thread:
            self.model.disconnect_chat()
            return
        self.start_chat(self.channel.text())

    def start_chat(self, channel):
        channel = channel.strip().lstrip("#")
        if not channel:
            return
        self.m.s["twitch_channel"] = channel
        token = None
        if self.m.twitch.signed_in():
            try:
                token = self.m.twitch.token()
            except Exception:
                token = None
        self.model.connect_chat(channel, self.m.twitch.login, token)

    def send(self):
        self.model.send(self.box.text())
        self.box.clear()

    def pop_out(self):
        w = QWidget()
        w.setWindowTitle("BeauShare chat")
        w.resize(380, 620)
        lay = QVBoxLayout(w)
        lay.setContentsMargins(10, 10, 10, 10)
        top = QCheckBox("Keep on top")
        top.toggled.connect(lambda on: (w.setWindowFlag(Qt.WindowStaysOnTopHint, on), w.show()))
        lay.addWidget(top)
        lay.addWidget(ChatView(self.m, self.model, compact=True), 1)
        w.setAttribute(Qt.WA_DeleteOnClose)
        w.show()
        self.popout = w
