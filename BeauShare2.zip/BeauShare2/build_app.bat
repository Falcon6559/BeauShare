@echo off
rem Shared step: builds dist\BeauShare\BeauShare.exe with FFmpeg bundled. Exit codes: 0 ok, 1 failed, 2 Python was just installed (re-run).
setlocal EnableExtensions
cd /d "%~dp0"

set "PY="
for %%V in (3.12 3.13 3.11 3.10) do if not defined PY py -%%V --version >nul 2>nul && set "PY=py -%%V"
if not defined PY python --version >nul 2>nul && set "PY=python"
if not defined PY goto :nopython

echo [1/3] Setting up Python...
if not exist ".venv\Scripts\python.exe" %PY% -m venv .venv
if errorlevel 1 goto :fail
call ".venv\Scripts\activate.bat"
python -m pip install --upgrade pip --quiet
pip install -r requirements.txt
if errorlevel 1 goto :fail

echo.
echo [2/3] Checking FFmpeg...
set "WG=%LOCALAPPDATA%\Microsoft\WinGet\Links\ffmpeg.exe"
set "FF="
if exist "%~dp0ffmpeg.exe" set "FF=%~dp0ffmpeg.exe"
if not defined FF for /f "delims=" %%F in ('where ffmpeg 2^>nul') do if not defined FF set "FF=%%F"
if not defined FF if exist "%WG%" set "FF=%WG%"
if defined FF goto :ffok
echo Installing FFmpeg with winget...
winget install -e --id Gyan.FFmpeg --accept-source-agreements --accept-package-agreements
if exist "%WG%" set "FF=%WG%"
:ffok
if not defined FF goto :noffmpeg

echo.
echo [3/3] Building the app (the slow part)...
set "QT_QPA_PLATFORM=offscreen"
python make_icon.py
set "QT_QPA_PLATFORM="
set "ICON="
if exist icon.ico set "ICON=--icon icon.ico"
pyinstaller --noconfirm --clean --windowed --name BeauShare %ICON% --hidden-import keyring.backends.Windows --collect-all googleapiclient --collect-data google_auth_oauthlib beaushare.py
if errorlevel 1 goto :fail
copy /y "%FF%" "dist\BeauShare\ffmpeg.exe" >nul
if errorlevel 1 goto :fail
copy /y "NOTICES.txt" "dist\BeauShare\NOTICES.txt" >nul
exit /b 0

:nopython
echo Python isn't installed. Installing Python 3.12 with winget...
winget install -e --id Python.Python.3.12 --accept-source-agreements --accept-package-agreements
exit /b 2

:noffmpeg
echo.
echo Couldn't find or install FFmpeg automatically.
echo Download "ffmpeg-release-essentials" from https://www.gyan.dev/ffmpeg/builds/
echo copy ffmpeg.exe (from its bin folder) into this folder, then run this again.
exit /b 1

:fail
exit /b 1
