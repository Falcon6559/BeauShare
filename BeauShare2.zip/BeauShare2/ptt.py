"""Push-to-talk: hold a key (or mouse button) to un-mute the microphone while recording."""
import ctypes
import time

from PySide6.QtCore import QObject, QTimer, Signal

user32 = ctypes.windll.user32 if hasattr(ctypes, "windll") else None

NAMES = {0x04: "Mouse middle", 0x05: "Mouse side 1", 0x06: "Mouse side 2", 0x14: "Caps Lock", 0x20: "Space",
         0xA0: "Left Shift", 0xA1: "Right Shift", 0xA2: "Left Ctrl", 0xA3: "Right Ctrl",
         0xA4: "Left Alt", 0xA5: "Right Alt", 0x5B: "Left Win", 0x5C: "Right Win"}
EXTENDED = {0x21, 0x22, 0x23, 0x24, 0x25, 0x26, 0x27, 0x28, 0x2D, 0x2E, 0x6F, 0x90}


def is_down(vk):
    return bool(user32 and vk and (user32.GetAsyncKeyState(vk) & 0x8000))


def key_name(vk):
    if vk in NAMES:
        return NAMES[vk]
    if user32:
        sc = user32.MapVirtualKeyW(vk, 0)
        buf = ctypes.create_unicode_buffer(64)
        if user32.GetKeyNameTextW((sc << 16) | ((1 << 24) if vk in EXTENDED else 0), buf, 64):
            return buf.value
    return f"Key {vk}"


class PushToTalk(QObject):
    live_changed = Signal(bool)
    RELEASE_DELAY = 0.2  # keep the mic open briefly so word endings aren't clipped

    def __init__(self, send):
        super().__init__()
        self.send, self.vk, self.live, self.off_at = send, 0, False, 0.0
        self.timer = QTimer(self)
        self.timer.timeout.connect(self._poll)

    def start(self, vk):
        self.vk, self.live, self.off_at = vk, False, 0.0
        self.timer.start(15)

    def stop(self):
        self.timer.stop()
        self.live = False

    def _poll(self):
        if is_down(self.vk):
            self.off_at = 0.0
            if not self.live:
                self._set(True)
        elif self.live:
            now = time.time()
            if not self.off_at:
                self.off_at = now + self.RELEASE_DELAY
            elif now >= self.off_at:
                self._set(False)

    def _set(self, live):
        self.live = live
        self.send(f"volume -1 volume {1 if live else 0}")  # FFmpeg runtime filter command
        self.live_changed.emit(live)


class KeyCapture(QObject):
    """Waits for the next key or mouse button press. Emits 0 if cancelled with Esc."""
    captured = Signal(int)
    SKIP = {0x01, 0x02, 0x10, 0x11, 0x12}  # left/right click, generic Shift/Ctrl/Alt

    def __init__(self):
        super().__init__()
        self.timer = QTimer(self)
        self.timer.timeout.connect(self._poll)
        self.held = set()

    def start(self):
        self.held = {vk for vk in range(1, 255) if is_down(vk)}
        self.timer.start(20)

    def _poll(self):
        for vk in range(1, 255):
            if vk in self.SKIP:
                continue
            if is_down(vk):
                if vk not in self.held:
                    self.timer.stop()
                    self.captured.emit(0 if vk == 0x1B else vk)
                    return
            else:
                self.held.discard(vk)
