"""Custom stream panels: text, image and live-chat panels drawn on a 1920x1080 canvas.

The same renderer draws the designer preview and the transparent overlay that FFmpeg
composites onto the stream (and optionally the recording).
"""
import json
import socket
import threading
import time
import uuid
from html import escape
from pathlib import Path

from PySide6.QtCore import QObject, QPointF, QRectF, Qt, QTimer, QUrl, Signal
from PySide6.QtGui import QColor, QFont, QImage, QLinearGradient, QPainter, QPainterPath, QPen, QPixmap, QTextDocument
from PySide6.QtWidgets import (QCheckBox, QColorDialog, QComboBox, QFileDialog, QFormLayout, QHBoxLayout, QLineEdit,
                               QListWidget, QListWidgetItem, QPlainTextEdit, QPushButton, QScrollArea, QSlider,
                               QSpinBox, QVBoxLayout, QWidget)

import engine
from ircparse import message_html
from theme import INK, LILAC, LINE, TALLY, label

W, H = 1920, 1080
FILE = engine.APPDATA / "panels.json"


# --------------------------------------------------------------------------- data
def new_panel(kind):
    p = dict(id=uuid.uuid4().hex[:8], type=kind, name=kind.title(), enabled=True, x=60, y=60, w=520, h=200,
             bg="#1E1929", bg_alpha=0.85, border="#B3A6FF", border_w=0, radius=18, opacity=1.0, padding=22,
             title="", text="", font_size=32, color="#F3EFFA", align="left", bold=True, image="", chat_lines=10)
    if kind == "text":
        p.update(name="Info panel", title="Welcome in!", text="Live for {uptime}")
    elif kind == "chat":
        p.update(name="Chat", x=1340, y=360, w=540, h=660, font_size=26, bg_alpha=0.55, radius=14, padding=16)
    elif kind == "image":
        p.update(name="Image", w=300, h=300, bg_alpha=0.0, padding=0)
    return p


class PanelStore:
    def __init__(self):
        try:
            self.panels = json.loads(FILE.read_text("utf-8"))
        except Exception:
            about = new_panel("text")
            about.update(name="Lower third", x=60, y=860, w=760, h=160, title="BeauShare", text="Live for {uptime}",
                         enabled=False)
            chat = new_panel("chat")
            chat.update(enabled=False)
            self.panels = [about, chat]

    def save(self):
        try:
            FILE.write_text(json.dumps(self.panels, indent=1), "utf-8")
        except Exception:
            pass

    def enabled(self):
        return [p for p in self.panels if p["enabled"]]

    def get(self, pid):
        return next((p for p in self.panels if p["id"] == pid), None)


# --------------------------------------------------------------------------- rendering
_imgs = {}


def _image(path):
    try:
        mt = Path(path).stat().st_mtime
    except OSError:
        return None
    if path not in _imgs or _imgs[path][0] != mt:
        _imgs[path] = (mt, QPixmap(path))
    return _imgs[path][1]


def _fill(text, tokens):
    for k, v in tokens.items():
        text = text.replace("{" + k + "}", str(v))
    return text


def _draw_doc(p, html, rect, px, model=None, bottom=False):
    doc = QTextDocument()
    f = QFont("Segoe UI")
    f.setPixelSize(px)
    doc.setDefaultFont(f)
    doc.setDocumentMargin(0)
    if model:
        for eid, pm in model.pix.items():
            doc.addResource(QTextDocument.ImageResource, QUrl(f"emote:{eid}"), pm)
    doc.setHtml(html)
    doc.setTextWidth(rect.width())
    h = doc.size().height()
    top = rect.bottom() - h if bottom else rect.top()
    p.save()
    p.translate(rect.left(), top)
    doc.drawContents(p)
    p.restore()


def draw_panels(p, panels, ctx, show_disabled=False):
    tokens, model = ctx["tokens"], ctx.get("model")
    for pn in panels:
        if not pn["enabled"] and not show_disabled:
            continue
        p.save()
        p.setOpacity(pn["opacity"] * (1.0 if pn["enabled"] else 0.35))
        rect = QRectF(pn["x"], pn["y"], pn["w"], pn["h"])
        path = QPainterPath()
        path.addRoundedRect(rect, pn["radius"], pn["radius"])
        bg = QColor(pn["bg"])
        bg.setAlphaF(pn["bg_alpha"])
        p.setPen(QPen(QColor(pn["border"]), pn["border_w"]) if pn["border_w"] > 0 else Qt.NoPen)
        p.setBrush(bg)
        p.drawPath(path)
        pad = pn["padding"]
        inner = rect.adjusted(pad, pad, -pad, -pad)
        p.setClipPath(path)
        p.setClipRect(inner, Qt.IntersectClip)
        px = int(pn["font_size"])
        if pn["type"] == "text":
            title = _fill(pn["title"], tokens)
            head = (f'<div style="font-size:{int(px * 1.3)}px;{"font-weight:700;" if pn["bold"] else ""}">'
                    f"{escape(title)}</div>") if title else ""
            body = escape(_fill(pn["text"], tokens)).replace("\n", "<br>")
            _draw_doc(p, f'<div align="{pn["align"]}" style="color:{pn["color"]}">{head}{body}</div>', inner, px)
        elif pn["type"] == "image":
            pm = _image(pn["image"]) if pn["image"] else None
            if pm and not pm.isNull():
                sc = pm.scaled(int(inner.width()), int(inner.height()), Qt.KeepAspectRatio, Qt.SmoothTransformation)
                p.drawPixmap(QPointF(inner.center().x() - sc.width() / 2, inner.center().y() - sc.height() / 2), sc)
        elif pn["type"] == "chat":
            msgs = list(model.recent)[-int(pn["chat_lines"]):] if model else []
            if not msgs:
                msgs = [{"system": True, "text": "Chat messages appear here", "ids": set()}]
            html = "".join(message_html(m, int(px * 1.1)) for m in msgs)
            _draw_doc(p, f'<div style="color:{pn["color"]}">{html}</div>', inner, px, model, bottom=True)
        p.restore()


def export_image(pn, ctx, width=320):
    """Render one panel as a PNG (Twitch channel panels are 320 px wide)."""
    sc = width / pn["w"]
    img = QImage(width, max(1, int(pn["h"] * sc)), QImage.Format_ARGB32)
    img.fill(0)
    p = QPainter(img)
    p.setRenderHint(QPainter.Antialiasing)
    p.setRenderHint(QPainter.TextAntialiasing)
    p.scale(sc, sc)
    p.translate(-pn["x"], -pn["y"])
    draw_panels(p, [dict(pn, enabled=True, opacity=1.0)], ctx)
    p.end()
    return img


# --------------------------------------------------------------------------- live overlay for FFmpeg
class OverlayFeeder(QObject):
    """Renders the panels ~5x a second and streams them to FFmpeg over a local socket."""
    FPS = 5

    def __init__(self, store, ctx_fn):
        super().__init__()
        self.store, self.ctx_fn = store, ctx_fn
        s = socket.socket()
        s.bind(("127.0.0.1", 0))
        self.port = s.getsockname()[1]
        s.close()
        self.latest, self.running, self.sock = None, False, None
        self.lock = threading.Lock()
        self.timer = QTimer(self)
        self.timer.timeout.connect(self.render)

    def input_args(self):
        return ["-f", "rawvideo", "-pixel_format", "bgra", "-video_size", f"{W}x{H}", "-framerate", str(self.FPS),
                "-use_wallclock_as_timestamps", "1", "-thread_queue_size", "8",
                "-i", f"tcp://127.0.0.1:{self.port}?listen=1&listen_timeout=20000"]

    def render(self):
        img = QImage(W, H, QImage.Format_ARGB32)
        img.fill(0)
        p = QPainter(img)
        p.setRenderHint(QPainter.Antialiasing)
        p.setRenderHint(QPainter.TextAntialiasing)
        draw_panels(p, self.store.panels, self.ctx_fn())
        p.end()
        data = bytes(img.constBits())
        with self.lock:
            self.latest = data

    def start(self):
        self.running = True
        self.render()
        self.timer.start(1000 // self.FPS)
        threading.Thread(target=self._send_loop, daemon=True).start()

    def _send_loop(self):
        end = time.time() + 20
        while self.running and not self.sock and time.time() < end:  # FFmpeg listens once it has started
            try:
                self.sock = socket.create_connection(("127.0.0.1", self.port), timeout=2)
            except OSError:
                time.sleep(0.1)
        nxt = time.perf_counter()
        while self.running and self.sock:
            with self.lock:
                data = self.latest
            try:
                self.sock.sendall(data)
            except OSError:
                break
            nxt += 1 / self.FPS
            time.sleep(max(0, nxt - time.perf_counter()))  # keeps sending even if the UI stalls

    def stop(self):
        self.running = False
        self.timer.stop()
        try:
            if self.sock:
                self.sock.close()
        except OSError:
            pass


# --------------------------------------------------------------------------- designer widgets
class PanelCanvas(QWidget):
    selected = Signal(str)
    edited = Signal()
    HANDLE = 22

    def __init__(self, store, ctx_fn):
        super().__init__()
        self.store, self.ctx_fn, self.sel, self.drag = store, ctx_fn, None, None
        self.setMinimumSize(480, 270)

    def geom(self):
        w = self.width()
        h = int(w * 9 / 16)
        if h > self.height():
            h = self.height()
            w = int(h * 16 / 9)
        return (self.width() - w) / 2, (self.height() - h) / 2, w / W

    def paintEvent(self, _):
        p = QPainter(self)
        p.setRenderHint(QPainter.Antialiasing)
        p.setRenderHint(QPainter.TextAntialiasing)
        ox, oy, sc = self.geom()
        p.fillRect(self.rect(), QColor(INK))
        p.translate(ox, oy)
        p.scale(sc, sc)
        g = QLinearGradient(0, 0, W, H)
        g.setColorAt(0, QColor("#2B2440"))
        g.setColorAt(1, QColor("#120F19"))
        p.fillRect(QRectF(0, 0, W, H), g)
        p.setPen(QColor("#4A4260"))
        f = QFont("Segoe UI")
        f.setPixelSize(54)
        p.setFont(f)
        p.drawText(QRectF(0, 0, W, H), Qt.AlignCenter, "Your screen: 1920 × 1080")
        draw_panels(p, self.store.panels, self.ctx_fn(), show_disabled=True)
        pn = self.store.get(self.sel)
        if pn:
            pen = QPen(QColor(LILAC), 3 / sc)
            pen.setStyle(Qt.DashLine)
            p.setPen(pen)
            p.setBrush(Qt.NoBrush)
            p.drawRect(QRectF(pn["x"], pn["y"], pn["w"], pn["h"]))
            p.setPen(Qt.NoPen)
            p.setBrush(QColor(LILAC))
            hs = self.HANDLE
            p.drawRect(QRectF(pn["x"] + pn["w"] - hs, pn["y"] + pn["h"] - hs, hs, hs))

    def _pt(self, e):
        ox, oy, sc = self.geom()
        return (e.position().x() - ox) / sc, (e.position().y() - oy) / sc

    def mousePressEvent(self, e):
        x, y = self._pt(e)
        pn = self.store.get(self.sel)
        hs = self.HANDLE
        if pn and pn["x"] + pn["w"] - hs <= x <= pn["x"] + pn["w"] and pn["y"] + pn["h"] - hs <= y <= pn["y"] + pn["h"]:
            self.drag = ("resize", 0, 0)
            return
        for pn in reversed(self.store.panels):
            if pn["x"] <= x <= pn["x"] + pn["w"] and pn["y"] <= y <= pn["y"] + pn["h"]:
                self.sel = pn["id"]
                self.drag = ("move", x - pn["x"], y - pn["y"])
                self.selected.emit(pn["id"])
                self.update()
                return
        self.sel, self.drag = None, None
        self.selected.emit("")
        self.update()

    def mouseMoveEvent(self, e):
        pn = self.store.get(self.sel)
        if not (pn and self.drag):
            return
        x, y = self._pt(e)
        kind, dx, dy = self.drag
        if kind == "move":
            pn["x"] = int(max(0, min(W - pn["w"], x - dx)))
            pn["y"] = int(max(0, min(H - pn["h"], y - dy)))
        else:
            pn["w"] = int(max(60, min(W - pn["x"], x - pn["x"])))
            pn["h"] = int(max(40, min(H - pn["y"], y - pn["y"])))
        self.edited.emit()
        self.update()

    def mouseReleaseEvent(self, _):
        if self.drag:
            self.store.save()
        self.drag = None


class ColorButton(QPushButton):
    changed = Signal(str)

    def __init__(self):
        super().__init__()
        self.c = "#ffffff"
        self.clicked.connect(self.pick)

    def set(self, c):
        self.c = c
        self.setStyleSheet(f"QPushButton{{background:{c};border:1px solid {LINE};min-height:20px;}}")

    def pick(self):
        col = QColorDialog.getColor(QColor(self.c), self, "Choose a colour")
        if col.isValid():
            self.set(col.name())
            self.changed.emit(col.name())


class FileButton(QPushButton):
    changed = Signal(str)

    def __init__(self):
        super().__init__("Choose image…")
        self.path = ""
        self.clicked.connect(self.pick)

    def set(self, path):
        self.path = path
        self.setText(Path(path).name if path else "Choose image…")

    def pick(self):
        f, _ = QFileDialog.getOpenFileName(self, "Choose an image", "", "Images (*.png *.jpg *.jpeg *.webp *.gif)")
        if f:
            self.set(f)
            self.changed.emit(f)


T, C, I = ("text",), ("chat",), ("image",)
SPECS = [  # key, label, kind, shown for types, options
    ("name", "Name", "line", None, {}),
    ("x", "X", "int", None, (0, W)), ("y", "Y", "int", None, (0, H)),
    ("w", "Width", "int", None, (60, W)), ("h", "Height", "int", None, (40, H)),
    ("title", "Title", "line", T, {}),
    ("text", "Text  ({uptime} {time} {viewers} {title})", "text", T, {}),
    ("font_size", "Text size", "int", ("text", "chat"), (10, 160)),
    ("color", "Text colour", "color", ("text", "chat"), {}),
    ("align", "Align", "combo", T, ["left", "center", "right"]),
    ("bold", "Bold title", "check", T, {}),
    ("image", "Image", "file", I, {}),
    ("chat_lines", "Messages shown", "int", C, (1, 30)),
    ("bg", "Background", "color", None, {}),
    ("bg_alpha", "Background opacity", "slider", None, {}),
    ("border", "Border colour", "color", None, {}),
    ("border_w", "Border width", "int", None, (0, 30)),
    ("radius", "Corner radius", "int", None, (0, 120)),
    ("padding", "Padding", "int", None, (0, 120)),
    ("opacity", "Panel opacity", "slider", None, {}),
]


class PropForm(QWidget):
    changed = Signal()

    def __init__(self):
        super().__init__()
        self.pn, self.loading, self.w = None, False, {}
        self.form = QFormLayout(self)
        self.form.setContentsMargins(0, 0, 0, 0)
        self.form.setLabelAlignment(Qt.AlignLeft)
        for key, lab, kind, types, opt in SPECS:
            if kind == "line":
                w = QLineEdit()
                w.textChanged.connect(lambda _, k=key: self.edit(k))
            elif kind == "text":
                w = QPlainTextEdit()
                w.setFixedHeight(90)
                w.textChanged.connect(lambda k=key: self.edit(k))
            elif kind == "int":
                w = QSpinBox()
                w.setRange(*opt)
                w.valueChanged.connect(lambda _, k=key: self.edit(k))
            elif kind == "slider":
                w = QSlider(Qt.Horizontal)
                w.setRange(0, 100)
                w.valueChanged.connect(lambda _, k=key: self.edit(k))
            elif kind == "color":
                w = ColorButton()
                w.changed.connect(lambda _, k=key: self.edit(k))
            elif kind == "combo":
                w = QComboBox()
                w.addItems(opt)
                w.currentTextChanged.connect(lambda _, k=key: self.edit(k))
            elif kind == "check":
                w = QCheckBox()
                w.toggled.connect(lambda _, k=key: self.edit(k))
            else:
                w = FileButton()
                w.changed.connect(lambda _, k=key: self.edit(k))
            self.form.addRow(lab, w)
            self.w[key] = (w, kind, types)

    def value(self, key):
        w, kind, _ = self.w[key]
        return {"line": lambda: w.text(), "text": lambda: w.toPlainText(), "int": lambda: w.value(),
                "slider": lambda: w.value() / 100, "color": lambda: w.c, "combo": lambda: w.currentText(),
                "check": lambda: w.isChecked(), "file": lambda: w.path}[kind]()

    def load(self, pn):
        self.pn, self.loading = pn, True
        for key, (w, kind, types) in self.w.items():
            self.form.setRowVisible(w, bool(pn) and (types is None or pn["type"] in types))
            if not pn:
                continue
            v = pn[key]
            if kind == "line":
                w.setText(v)
            elif kind == "text":
                w.setPlainText(v)
            elif kind == "int":
                w.setValue(int(v))
            elif kind == "slider":
                w.setValue(int(v * 100))
            elif kind in ("color", "file"):
                w.set(v)
            elif kind == "combo":
                w.setCurrentText(v)
            else:
                w.setChecked(bool(v))
        self.loading = False

    def edit(self, key):
        if self.loading or not self.pn:
            return
        self.pn[key] = self.value(key)
        self.changed.emit()


class PanelsPage(QWidget):
    def __init__(self, main):
        super().__init__()
        self.setObjectName("Page")
        self.m, self.store = main, main.panels
        lay = QHBoxLayout(self)
        lay.setContentsMargins(28, 24, 28, 20)
        lay.setSpacing(18)

        left = QVBoxLayout()
        left.addWidget(label("Panels", "Brand"))
        left.addWidget(label("Drag to move. Drag the lilac corner to resize. Tick a panel to show it on your stream.",
                             "Hint"))
        left.itemAt(1).widget().setWordWrap(True)
        self.canvas = PanelCanvas(self.store, main.panel_ctx)
        self.canvas.selected.connect(self.on_canvas_select)
        self.canvas.edited.connect(self.on_canvas_edit)
        left.addWidget(self.canvas, 1)
        self.rec_chk = QCheckBox("Also show panels in my recordings")
        self.rec_chk.setChecked(main.s["panels_in_recording"])
        self.rec_chk.toggled.connect(lambda v: main.s.__setitem__("panels_in_recording", v))
        left.addWidget(self.rec_chk)
        lay.addLayout(left, 1)

        right = QVBoxLayout()
        right.setSpacing(8)
        right.addWidget(label("Your panels", "H"))
        self.list = QListWidget()
        self.list.setFixedHeight(150)
        self.list.currentRowChanged.connect(self.on_list_select)
        self.list.itemChanged.connect(self.on_check)
        right.addWidget(self.list)
        row = QHBoxLayout()
        for text, kind in (("+ Text", "text"), ("+ Chat", "chat"), ("+ Image", "image")):
            b = QPushButton(text)
            b.clicked.connect(lambda _, k=kind: self.add(k))
            row.addWidget(b)
        right.addLayout(row)
        row = QHBoxLayout()
        for text, fn in (("Duplicate", self.duplicate), ("Delete", self.delete),
                         ("Up", lambda: self.move(-1)), ("Down", lambda: self.move(1))):
            b = QPushButton(text)
            b.clicked.connect(fn)
            row.addWidget(b)
        right.addLayout(row)
        self.form = PropForm()
        self.form.changed.connect(self.on_form_change)
        sa = QScrollArea()
        sa.setWidgetResizable(True)
        sa.setWidget(self.form)
        sa.setFrameShape(QScrollArea.NoFrame)
        sa.setFixedWidth(330)
        right.addWidget(sa, 1)
        exp = QPushButton("Export as Twitch panel image (320 px)")
        exp.clicked.connect(self.export)
        right.addWidget(exp)
        lay.addLayout(right)
        for b in self.findChildren(QPushButton):
            b.setFocusPolicy(Qt.NoFocus)
        self.refresh()

        self.tick = QTimer(self)  # keeps live chat and clock tokens moving in the preview
        self.tick.timeout.connect(self.canvas.update)
        self.tick.start(500)

    def refresh(self, select=None):
        self.list.blockSignals(True)
        self.list.clear()
        for pn in self.store.panels:
            it = QListWidgetItem(pn["name"])
            it.setFlags(it.flags() | Qt.ItemIsUserCheckable)
            it.setCheckState(Qt.Checked if pn["enabled"] else Qt.Unchecked)
            it.setData(Qt.UserRole, pn["id"])
            self.list.addItem(it)
        sel = select or self.canvas.sel
        for i, pn in enumerate(self.store.panels):
            if pn["id"] == sel:
                self.list.setCurrentRow(i)
        self.list.blockSignals(False)
        self.form.load(self.store.get(sel))
        self.canvas.sel = sel if self.store.get(sel) else None
        self.canvas.update()

    def current(self):
        return self.store.get(self.canvas.sel)

    def on_list_select(self, row):
        if 0 <= row < len(self.store.panels):
            self.canvas.sel = self.store.panels[row]["id"]
            self.form.load(self.current())
            self.canvas.update()

    def on_canvas_select(self, pid):
        self.refresh(pid or None)

    def on_canvas_edit(self):
        self.form.load(self.current())

    def on_check(self, it):
        pn = self.store.get(it.data(Qt.UserRole))
        if pn:
            pn["enabled"] = it.checkState() == Qt.Checked
            self.store.save()
            self.canvas.update()

    def on_form_change(self):
        pn = self.current()
        if pn:
            row = self.store.panels.index(pn)
            if self.list.item(row).text() != pn["name"]:
                self.list.blockSignals(True)
                self.list.item(row).setText(pn["name"])
                self.list.blockSignals(False)
        self.store.save()
        self.canvas.update()

    def add(self, kind):
        pn = new_panel(kind)
        self.store.panels.append(pn)
        self.store.save()
        self.refresh(pn["id"])

    def duplicate(self):
        pn = self.current()
        if pn:
            c = dict(pn, id=new_panel("text")["id"], name=pn["name"] + " copy", x=pn["x"] + 30, y=pn["y"] + 30)
            self.store.panels.append(c)
            self.store.save()
            self.refresh(c["id"])

    def delete(self):
        pn = self.current()
        if pn:
            self.store.panels.remove(pn)
            self.canvas.sel = None
            self.store.save()
            self.refresh()

    def move(self, d):
        pn = self.current()
        if pn:
            i = self.store.panels.index(pn)
            j = i + d
            if 0 <= j < len(self.store.panels):
                self.store.panels[i], self.store.panels[j] = self.store.panels[j], self.store.panels[i]
                self.store.save()
                self.refresh(pn["id"])

    def export(self):
        pn = self.current()
        if not pn:
            return
        f, _ = QFileDialog.getSaveFileName(self, "Save panel image", f"{pn['name']}.png", "PNG (*.png)")
        if f:
            export_image(pn, self.m.panel_ctx()).save(f)
