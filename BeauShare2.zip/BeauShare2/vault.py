"""Secrets (stream keys, tokens) live in Windows Credential Manager via keyring."""
try:
    import keyring
except ImportError:  # app still works; secrets last for this session only
    keyring = None

SERVICE = "BeauShare"
_mem = {}


def available():
    return keyring is not None


def get(name):
    if keyring:
        try:
            return keyring.get_password(SERVICE, name) or ""
        except Exception:
            pass
    return _mem.get(name, "")


def put(name, value):
    _mem[name] = value
    if keyring:
        try:
            if value:
                keyring.set_password(SERVICE, name, value)
            else:
                try:
                    keyring.delete_password(SERVICE, name)
                except Exception:
                    pass
        except Exception:
            pass
