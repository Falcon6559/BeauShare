"""Shared palette and small UI helpers."""
import os
import re
import subprocess

from PySide6.QtWidgets import QFrame, QLabel

INK, PANEL, LINE = "#17131F", "#1E1929", "#332C45"
TEXT, MUTED = "#F3EFFA", "#A097B5"
TALLY, LILAC = "#FF4D5E", "#B3A6FF"


def hline():
    f = QFrame()
    f.setObjectName("Rule")
    return f


def label(text, name=None):
    l = QLabel(text)
    if name:
        l.setObjectName(name)
    return l


def human_size(n):
    for u in ("B", "KB", "MB", "GB"):
        if n < 1024 or u == "GB":
            return f"{n:.0f} {u}" if u == "B" else f"{n:.1f} {u}"
        n /= 1024


def reveal(path):
    subprocess.Popen(["explorer", "/select,", os.path.normpath(path)])


def safe_name(s):
    return re.sub(r'[<>:"/\\|?*]', "_", s).strip() or "BeauShare"


def fmt_ms(ms):
    ms = max(0, int(ms))
    s, t = divmod(ms, 1000)
    m, s = divmod(s, 60)
    h, m = divmod(m, 60)
    return f"{h}:{m:02d}:{s:02d}.{t // 100}" if h else f"{m}:{s:02d}.{t // 100}"
