"""Twitch sign-in (device code flow, no client secret) and the few Helix calls BeauShare needs."""
import json
import time
import urllib.error
import urllib.parse
import urllib.request

import vault

SCOPES = "chat:read chat:edit channel:read:stream_key channel:manage:broadcast"
ID = "https://id.twitch.tv/oauth2"
HELIX = "https://api.twitch.tv/helix"


class TwitchError(Exception):
    pass


def _call(req):
    try:
        with urllib.request.urlopen(req, timeout=20) as r:
            raw = r.read().decode("utf-8")
            return json.loads(raw) if raw else {}
    except urllib.error.HTTPError as e:
        try:
            msg = json.loads(e.read().decode("utf-8")).get("message", "")
        except Exception:
            msg = ""
        raise TwitchError(msg or f"HTTP {e.code}")
    except urllib.error.URLError as e:
        raise TwitchError(f"Can't reach Twitch ({e.reason})")


def _form(url, data):
    return _call(urllib.request.Request(url, urllib.parse.urlencode(data).encode(), method="POST"))


def device_start(client_id):
    return _form(f"{ID}/device", {"client_id": client_id, "scopes": SCOPES})


def device_poll(client_id, info):
    """Blocks until the user approves the code in their browser (or it expires)."""
    end = time.time() + int(info.get("expires_in", 600))
    wait = int(info.get("interval", 5))
    while time.time() < end:
        time.sleep(wait)
        try:
            return _form(f"{ID}/token", {
                "client_id": client_id, "scopes": SCOPES, "device_code": info["device_code"],
                "grant_type": "urn:ietf:params:oauth:grant-type:device_code"})
        except TwitchError as e:
            if "pending" in str(e).lower():
                continue
            raise
    raise TwitchError("The code expired. Try signing in again.")


class Auth:
    """Holds the signed-in user's tokens (stored in Credential Manager)."""

    def __init__(self, settings):
        self.s = settings
        try:
            self.d = json.loads(vault.get("twitch_tokens") or "{}")
        except Exception:
            self.d = {}

    @property
    def client_id(self):
        return self.s["twitch_client_id"]

    def signed_in(self):
        return bool(self.d.get("access") and self.d.get("login"))

    @property
    def login(self):
        return self.d.get("login", "")

    @property
    def user_id(self):
        return self.d.get("user_id", "")

    def _save(self):
        vault.put("twitch_tokens", json.dumps(self.d))

    def complete(self, tok):
        self.d = {"access": tok["access_token"], "refresh": tok.get("refresh_token", ""),
                  "expires_at": time.time() + int(tok.get("expires_in", 3600))}
        info = _call(urllib.request.Request(f"{ID}/validate", headers={"Authorization": f"OAuth {self.d['access']}"}))
        self.d["login"], self.d["user_id"] = info["login"], info["user_id"]
        self._save()

    def sign_out(self):
        self.d = {}
        self._save()

    def token(self):
        if time.time() > self.d.get("expires_at", 0) - 120 and self.d.get("refresh"):
            tok = _form(f"{ID}/token", {"client_id": self.client_id, "grant_type": "refresh_token",
                                        "refresh_token": self.d["refresh"]})
            self.d["access"] = tok["access_token"]
            self.d["refresh"] = tok.get("refresh_token", self.d["refresh"])
            self.d["expires_at"] = time.time() + int(tok.get("expires_in", 3600))
            self._save()
        return self.d["access"]

    def _helix(self, method, path, params=None, body=None):
        url = f"{HELIX}/{path}" + ("?" + urllib.parse.urlencode(params) if params else "")
        headers = {"Authorization": f"Bearer {self.token()}", "Client-Id": self.client_id}
        data = None
        if body is not None:
            data, headers["Content-Type"] = json.dumps(body).encode(), "application/json"
        return _call(urllib.request.Request(url, data, headers, method=method))

    def stream_key(self):
        return self._helix("GET", "streams/key", {"broadcaster_id": self.user_id})["data"][0]["stream_key"]

    def set_title(self, title):
        self._helix("PATCH", "channels", {"broadcaster_id": self.user_id}, {"title": title[:140]})

    def viewers(self):
        data = self._helix("GET", "streams", {"user_id": self.user_id})["data"]
        return data[0]["viewer_count"] if data else None  # None = not live yet
