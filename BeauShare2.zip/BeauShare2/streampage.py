"""The Stream page: go live to Twitch and/or YouTube, Twitch sign-in, and the chat view."""
import webbrowser

from PySide6.QtCore import Qt, QThread, QTimer, Signal
from PySide6.QtWidgets import (QCheckBox, QComboBox, QFrame, QHBoxLayout, QLineEdit, QMessageBox, QPushButton,
                               QScrollArea, QSpinBox, QVBoxLayout, QWidget)

import twitch
import vault
from chat import ChatView
from theme import hline, label


class Job(QThread):
    done = Signal(object)
    failed = Signal(str)

    def __init__(self, fn, *args):
        super().__init__()
        self.fn, self.args = fn, args

    def run(self):
        try:
            self.done.emit(self.fn(*self.args))
        except Exception as e:
            self.failed.emit(str(e))


class StreamPage(QWidget):
    def __init__(self, main):
        super().__init__()
        self.setObjectName("Page")
        self.m, self.s, self.jobs = main, main.s, []
        self.viewers = None
        outer = QHBoxLayout(self)
        outer.setContentsMargins(28, 24, 28, 20)
        outer.setSpacing(20)

        # ---- left column (scrolls so small windows still work)
        col = QWidget()
        col.setObjectName("Page")
        v = QVBoxLayout(col)
        v.setContentsMargins(0, 0, 12, 0)
        v.setSpacing(8)
        v.addWidget(label("Stream", "Brand"))
        self.state = label("Offline", "Status")
        self.go = QPushButton("Go live")
        self.go.setObjectName("Go")
        self.go.setMinimumHeight(46)
        self.go.clicked.connect(self.toggle)
        self.stats = label("", "Hint")
        self.warn = label("", "Hint")
        self.warn.setWordWrap(True)
        self.warn.setStyleSheet("color:#FF4D5E;")
        for w in (self.state, self.go, self.stats, self.warn):
            v.addWidget(w)

        v.addSpacing(6)
        v.addWidget(hline())
        v.addWidget(label("Stream title", "H"))
        self.title = QLineEdit(self.s["stream_title"])
        self.title.setPlaceholderText("What are you streaming?")
        self.title.editingFinished.connect(lambda: self.s.__setitem__("stream_title", self.title.text()))
        v.addWidget(self.title)

        v.addWidget(label("Where to stream", "H"))
        self.tw_chk = QCheckBox("Twitch")
        self.tw_chk.setChecked(self.s["stream_twitch"])
        self.tw_key = self.key_field("twitch_key", "Twitch stream key")
        self.tw_get = QPushButton("Get my key from Twitch")
        self.tw_get.clicked.connect(self.fetch_key)
        self.yt_chk = QCheckBox("YouTube")
        self.yt_chk.setChecked(self.s["stream_youtube"])
        self.yt_key = self.key_field("youtube_key", "YouTube stream key (from YouTube Studio, Go live)")
        self.tls = QCheckBox("Encrypted connection (RTMPS)")
        self.tls.setChecked(self.s["stream_rtmps"])
        for w in (self.tw_chk, self.tw_key, self.tw_get, self.yt_chk, self.yt_key, self.tls):
            v.addWidget(w)
        if not vault.available():
            v.addWidget(label("Install the keyring package to save keys between sessions.", "Hint"))

        v.addSpacing(4)
        v.addWidget(label("Video", "H"))
        self.bitrate = QSpinBox()
        self.bitrate.setRange(1000, 20000)
        self.bitrate.setSingleStep(500)
        self.bitrate.setSuffix(" kbps")
        self.bitrate.setValue(self.s["stream_bitrate"])
        self.res = QComboBox()
        self.res.addItems(["1440p", "1080p", "720p", "480p"])
        self.res.setCurrentText(self.s["stream_res"])
        self.fps = QComboBox()
        self.fps.addItems(["30", "60"])
        self.fps.setCurrentText(str(self.s["stream_fps"]))
        self.rec_chk = QCheckBox("Save a full-quality recording while live")
        self.rec_chk.setChecked(self.s["stream_record"])
        row = QHBoxLayout()
        for w in (self.res, self.fps):
            row.addWidget(w)
        v.addWidget(self.bitrate)
        v.addLayout(row)
        v.addWidget(self.rec_chk)
        v.addWidget(label("Twitch allows up to about 8000 kbps. 6000 kbps at 1080p30 is a safe start.", "Hint"))
        v.itemAt(v.count() - 1).widget().setWordWrap(True)

        v.addSpacing(6)
        v.addWidget(hline())
        v.addWidget(label("Twitch account", "H"))
        self.acct = label("", "Muted")
        self.acct.setWordWrap(True)
        self.acct.setTextInteractionFlags(Qt.TextSelectableByMouse)
        self.cid = QLineEdit(self.s["twitch_client_id"])
        self.cid.setPlaceholderText("Twitch application Client ID")
        self.cid.editingFinished.connect(lambda: self.s.__setitem__("twitch_client_id", self.cid.text().strip()))
        row = QHBoxLayout()
        self.sign_in_btn = QPushButton("Sign in")
        self.sign_in_btn.clicked.connect(self.sign_in)
        self.sign_out_btn = QPushButton("Sign out")
        self.sign_out_btn.clicked.connect(self.sign_out)
        row.addWidget(self.sign_in_btn)
        row.addWidget(self.sign_out_btn)
        help_ = label("Signing in lets you chat, fetch your stream key, set your title and see viewers. One-time "
                      "setup: create a free app at dev.twitch.tv/console with Client Type “Public” and any redirect "
                      "URL (http://localhost), then paste its Client ID here.", "Hint")
        help_.setWordWrap(True)
        for w in (self.acct, self.cid):
            v.addWidget(w)
        v.addLayout(row)
        v.addWidget(help_)
        v.addStretch()

        sa = QScrollArea()
        sa.setWidgetResizable(True)
        sa.setWidget(col)
        sa.setFrameShape(QFrame.NoFrame)
        sa.setFixedWidth(400)
        outer.addWidget(sa)

        # ---- chat
        right = QVBoxLayout()
        right.addWidget(label("Twitch chat", "H"))
        self.chat = ChatView(main, main.chat)
        right.addWidget(self.chat, 1)
        outer.addLayout(right, 1)

        self.clock = QTimer(self)
        self.clock.timeout.connect(self.tick)
        self.clock.start(1000)
        self.poll = QTimer(self)
        self.poll.timeout.connect(self.poll_viewers)
        self.poll.start(30000)
        self.refresh_account()
        main.rec and main.rec.stats.connect(self.on_stats)
        main.rec and main.rec.line.connect(self.on_line)
        main.chat.status.connect(lambda _: self.chat.refresh_input())
        if self.s["twitch_channel"] or main.twitch.signed_in():
            QTimer.singleShot(500, lambda: self.chat.start_chat(self.s["twitch_channel"] or main.twitch.login))

    # ---- helpers
    def key_field(self, name, placeholder):
        e = QLineEdit(vault.get(name))
        e.setEchoMode(QLineEdit.Password)
        e.setPlaceholderText(placeholder)
        e.editingFinished.connect(lambda: vault.put(name, e.text().strip()))
        e.setProperty("vault", name)
        return e

    def keys(self):
        return vault.get("twitch_key") or self.tw_key.text().strip(), vault.get("youtube_key") or self.yt_key.text().strip()

    def urls(self):
        tw, yt = self.keys()
        tls = self.tls.isChecked()
        out = []
        if self.tw_chk.isChecked() and tw:
            out.append(f"rtmps://live.twitch.tv:443/app/{tw}" if tls else f"rtmp://live.twitch.tv/app/{tw}")
        if self.yt_chk.isChecked() and yt:
            out.append(f"rtmps://a.rtmps.youtube.com:443/live2/{yt}" if tls else f"rtmp://a.rtmp.youtube.com/live2/{yt}")
        return out

    def run(self, fn, ok, *args):
        job = Job(fn, *args)
        job.done.connect(ok)
        job.failed.connect(lambda e: self.warn.setText(e[:300]))
        job.finished.connect(lambda j=job: self.jobs.remove(j) if j in self.jobs else None)
        self.jobs.append(job)
        job.start()

    def save_prefs(self):
        self.s.data.update(stream_twitch=self.tw_chk.isChecked(), stream_youtube=self.yt_chk.isChecked(),
                           stream_rtmps=self.tls.isChecked(), stream_bitrate=self.bitrate.value(),
                           stream_res=self.res.currentText(), stream_fps=int(self.fps.currentText()),
                           stream_record=self.rec_chk.isChecked(), stream_title=self.title.text())
        vault.put("twitch_key", self.tw_key.text().strip())
        vault.put("youtube_key", self.yt_key.text().strip())
        self.s.save()

    # ---- going live
    def toggle(self):
        m = self.m
        if m.mode == "live":
            m.stop_capture()
            return
        if m.mode != "idle" or not m.rec:
            QMessageBox.information(self, "BeauShare", "Finish the current recording first." if m.rec
                                    else "FFmpeg is needed to stream. Install it from the Record page.")
            return
        self.save_prefs()
        urls = self.urls()
        if not urls:
            QMessageBox.information(self, "BeauShare", "Turn on Twitch or YouTube and paste its stream key first.")
            return
        self.warn.setText("")
        if self.s["stream_title"] and m.twitch.signed_in() and self.tw_chk.isChecked():
            self.run(lambda: m.twitch.set_title(self.s["stream_title"]), lambda _: None)
        m.start_live(dict(urls=urls, bitrate=self.bitrate.value(), resolution=self.res.currentText(),
                          fps=int(self.fps.currentText()), record=self.rec_chk.isChecked()),
                     secrets=list(self.keys()))

    def refresh_state(self):
        live, mode = self.m.mode == "live", self.m.mode
        self.go.setText("Stop streaming" if live else "Go live")
        self.go.setEnabled(mode in ("idle", "live"))
        self.tick()

    def tick(self):
        m = self.m
        if m.mode == "live":
            t = int(m.rec.elapsed())
            v = f" · {self.viewers} watching" if self.viewers is not None else ""
            self.state.setText(f"LIVE {t // 3600:02d}:{t % 3600 // 60:02d}:{t % 60:02d}{v}")
            self.state.setStyleSheet("color:#FF4D5E;font-weight:700;")
        else:
            self.state.setText("Offline" if m.mode == "idle" else "Recording (stop it to go live)")
            self.state.setStyleSheet("")
            self.stats.setText("")

    def on_stats(self, st):
        if self.m.mode != "live":
            return
        try:
            kb = float(st.get("bitrate", "0").replace("kbits/s", "") or 0)
        except ValueError:
            kb = 0
        self.stats.setText(f"{kb:,.0f} kbps · {float(st.get('fps', 0) or 0):.0f} fps · "
                           f"{st.get('drop_frames', '0')} dropped · speed {st.get('speed', '?')}")

    def on_line(self, text):
        if self.m.mode == "live" and any(w in text.lower() for w in ("error", "fail", "refused", "timed out")):
            self.warn.setText(text[:240])

    def poll_viewers(self):
        if self.m.mode == "live" and self.m.twitch.signed_in():
            self.run(self.m.twitch.viewers, self.set_viewers)

    def set_viewers(self, n):
        self.viewers = n

    # ---- Twitch account
    def refresh_account(self):
        a = self.m.twitch
        if a.signed_in():
            self.acct.setText(f"Signed in as {a.login}.")
        else:
            self.acct.setText("Not signed in. You can still read chat and stream with a pasted stream key.")
        self.sign_in_btn.setEnabled(not a.signed_in())
        self.sign_out_btn.setEnabled(a.signed_in())
        self.tw_get.setEnabled(a.signed_in())
        self.chat.refresh_input()

    def sign_in(self):
        cid = self.cid.text().strip()
        if not cid:
            QMessageBox.information(self, "Twitch", "Paste your Twitch application's Client ID first. The note "
                                    "below the button explains how to get one (it's free).")
            return
        self.s["twitch_client_id"] = cid
        self.acct.setText("Contacting Twitch…")
        self.run(twitch.device_start, self.got_code, cid)

    def got_code(self, info):
        webbrowser.open(info["verification_uri"])
        self.acct.setText(f"Approve BeauShare in the browser tab that just opened.\nYour code: "
                          f"{info['user_code']}\n(or visit {info['verification_uri']})")
        self.run(twitch.device_poll, self.got_tokens, self.s["twitch_client_id"], info)

    def got_tokens(self, tok):
        try:
            self.m.twitch.complete(tok)
        except Exception as e:
            self.warn.setText(str(e)[:300])
        self.refresh_account()
        if self.m.twitch.signed_in() and not self.m.chat.thread:
            self.chat.channel.setText(self.m.twitch.login)
            self.chat.start_chat(self.m.twitch.login)

    def sign_out(self):
        self.m.twitch.sign_out()
        self.m.chat.disconnect_chat()
        self.refresh_account()

    def fetch_key(self):
        self.run(self.m.twitch.stream_key, self.set_key)

    def set_key(self, key):
        self.tw_key.setText(key)
        vault.put("twitch_key", key)
        self.warn.setText("")
