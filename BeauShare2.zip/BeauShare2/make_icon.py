from PySide6.QtWidgets import QApplication
import sys
from beaushare import app_pixmap
app = QApplication(sys.argv)
app_pixmap(256).save("icon.ico")
