"""Twitch IRC parsing and chat-message HTML. No Qt, so it can be tested on its own."""
import re
from html import escape

PALETTE = ["#FF4D5E", "#1E90FF", "#00C77F", "#B22222", "#FF7F50", "#9ACD32", "#FF8C1A",
           "#D2691E", "#5F9EA0", "#8A7BFF", "#FF69B4", "#2E8B57"]
BADGES = {"broadcaster": ("LIVE", "#E91916"), "moderator": ("MOD", "#00AD03"),
          "vip": ("VIP", "#E005B9"), "subscriber": ("SUB", "#8A7BFF")}
EMOTE_URL = "https://static-cdn.jtvnw.net/emoticons/v2/{}/default/dark/1.0"


def unescape_tag(v):
    return (v.replace("\\s", " ").replace("\\:", ";").replace("\\r", "").replace("\\n", " ")
            .replace("\\\\", "\\"))


def parse_irc(line):
    tags = {}
    if line.startswith("@"):
        raw, line = line.split(" ", 1)
        for kv in raw[1:].split(";"):
            k, _, v = kv.partition("=")
            tags[k] = v
    prefix = ""
    if line.startswith(":"):
        prefix, _, line = line[1:].partition(" ")
    head, _, trailing = line.partition(" :")
    parts = head.split()
    return tags, prefix, (parts[0] if parts else ""), parts[1:], trailing


def legible(color, name=""):
    if not re.fullmatch(r"#[0-9a-fA-F]{6}", color or ""):
        color = PALETTE[sum(map(ord, name)) % len(PALETTE)]
    r, g, b = (int(color[i:i + 2], 16) for i in (1, 3, 5))
    if 0.299 * r + 0.587 * g + 0.114 * b < 110:  # too dark for a dark background
        r, g, b = (int(c + (255 - c) * 0.5) for c in (r, g, b))
    return f"#{r:02X}{g:02X}{b:02X}"


def make_message(tags, prefix, cmd, trailing):
    """Returns a message dict for PRIVMSG / USERNOTICE, else None."""
    if cmd == "USERNOTICE":
        text = unescape_tag(tags.get("system-msg", ""))
        return {"system": True, "text": text, "name": "", "color": "", "badges": [], "emotes": [], "ids": set(),
                "action": False} if text else None
    if cmd != "PRIVMSG":
        return None
    nick = prefix.split("!")[0]
    name = unescape_tag(tags.get("display-name", "")) or nick
    action = trailing.startswith("\x01ACTION ")
    text = trailing[8:].rstrip("\x01") if action else trailing
    emotes = []
    for grp in filter(None, tags.get("emotes", "").split("/")):
        eid, _, ranges = grp.partition(":")
        for r in ranges.split(","):
            a, _, b = r.partition("-")
            if a.isdigit() and b.isdigit():
                emotes.append((eid, int(a), int(b)))
    emotes.sort(key=lambda e: e[1])
    badges = [b.split("/")[0] for b in tags.get("badges", "").split(",") if b]
    return {"system": False, "name": name, "color": legible(tags.get("color", ""), name), "badges": badges,
            "emotes": emotes, "ids": {e[0] for e in emotes}, "text": text, "action": action}


def message_html(msg, emote_px=22):
    if msg["system"]:
        return f'<div style="color:#A097B5"><i>{escape(msg["text"])}</i></div>'
    out, pos, text = [], 0, msg["text"]
    for eid, a, b in msg["emotes"]:
        if a < pos:
            continue
        out.append(escape(text[pos:a]))
        out.append(f'<img src="emote:{eid}" height="{emote_px}" />')
        pos = b + 1
    out.append(escape(text[pos:]))
    body = "".join(out)
    badges = "".join(f'<span style="background-color:{BADGES[b][1]};color:#fff"> {BADGES[b][0]} </span> '
                     for b in msg["badges"] if b in BADGES)
    name = f'<b style="color:{msg["color"]}">{escape(msg["name"])}</b>'
    if msg["action"]:
        return f'<div>{badges}{name} <span style="color:{msg["color"]}">{body}</span></div>'
    return f"<div>{badges}{name}: {body}</div>"
