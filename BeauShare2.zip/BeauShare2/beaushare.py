"""BeauShare - screen recorder with save destinations and YouTube upload (Windows 11)."""
import ctypes
import math
import os
import re
import subprocess
import sys
import time
from ctypes import wintypes
from datetime import datetime
from pathlib import Path

from PySide6.QtCore import (QAbstractNativeEventFilter, QPointF, QRectF, Qt, QThread, QTimer, Signal)
from PySide6.QtGui import QColor, QFont, QIcon, QPainter, QPen, QPixmap
from PySide6.QtWidgets import (QAbstractButton, QApplication, QCheckBox, QComboBox, QDialog, QFileDialog,
                               QFrame, QHBoxLayout, QLabel, QLineEdit, QListWidget, QListWidgetItem,
                               QMessageBox, QPlainTextEdit, QProgressBar, QPushButton, QStackedWidget,
                               QVBoxLayout, QWidget)

import engine
import twitch
import youtube
from chat import ChatModel
from panels import OverlayFeeder, PanelsPage, PanelStore
from streampage import StreamPage
from editor import EditorPage
from ptt import KeyCapture, PushToTalk, key_name
from theme import (INK, LILAC, LINE, MUTED, PANEL, TALLY, TEXT, hline, human_size, label, reveal, safe_name)

# Palette: aubergine ink, one signal colour (the tally light), a calm lilac for selection.

QSS = f"""
* {{ font-family: "Segoe UI Variable Text","Segoe UI"; font-size: 10pt; color: {TEXT}; }}
QWidget#Root, QStackedWidget, QWidget#Page {{ background: {INK}; }}
QWidget#Side {{ background: {PANEL}; }}
QLabel {{ background: transparent; }}
QLabel#Brand {{ font-family: "Bahnschrift"; font-size: 17pt; font-weight: 600; }}
QLabel#Timer {{ font-family: "Bahnschrift"; font-size: 54pt; font-weight: 300; }}
QLabel#Muted, QLabel#Hint {{ color: {MUTED}; }}
QLabel#H {{ font-size: 11pt; font-weight: 600; }}
QLabel#Status {{ color: {MUTED}; font-size: 11pt; }}
QFrame#Rule {{ background: {LINE}; max-height: 1px; min-height: 1px; border: none; }}
QFrame#Banner {{ background: #3A1E2B; border: 1px solid {TALLY}; border-radius: 8px; }}
QPushButton {{ background: {PANEL}; border: 1px solid {LINE}; border-radius: 8px; padding: 8px 14px; }}
QPushButton:hover {{ border-color: {LILAC}; }}
QPushButton:disabled {{ color: #6b6380; border-color: #28223a; }}
QPushButton#Nav {{ text-align: left; border: none; background: transparent; padding: 11px 14px;
                   color: {MUTED}; font-weight: 600; border-radius: 8px; }}
QPushButton#Nav:hover {{ color: {TEXT}; }}
QPushButton#Nav:checked {{ background: {INK}; color: {TEXT}; }}
QPushButton#Go {{ background: {TALLY}; border: none; font-weight: 600; color: white; }}
QPushButton#Go:hover {{ background: #ff6b79; }}
QPushButton#Go:disabled {{ background: #4a3a4c; color: #8d8299; }}
QComboBox, QLineEdit, QPlainTextEdit, QListWidget {{ background: {PANEL}; border: 1px solid {LINE};
        border-radius: 8px; padding: 6px 8px; selection-background-color: {LILAC}; selection-color: {INK}; }}
QComboBox:focus, QLineEdit:focus, QPlainTextEdit:focus {{ border-color: {LILAC}; }}
QComboBox QAbstractItemView {{ background: {PANEL}; border: 1px solid {LINE}; selection-background-color: {LILAC};
        selection-color: {INK}; }}
QListWidget::item {{ padding: 9px 8px; border-radius: 6px; }}
QListWidget::item:selected {{ background: {LINE}; color: {TEXT}; }}
QCheckBox {{ spacing: 8px; background: transparent; }}
QCheckBox::indicator {{ width: 16px; height: 16px; border-radius: 4px; border: 1px solid {MUTED}; }}
QCheckBox::indicator:checked {{ background: {LILAC}; border-color: {LILAC}; }}
QProgressBar {{ background: {PANEL}; border: 1px solid {LINE}; border-radius: 6px; height: 12px; text-align: center; }}
QProgressBar::chunk {{ background: {LILAC}; border-radius: 5px; }}
QDialog {{ background: {INK}; }}
QScrollArea {{ background: {INK}; border: none; }}
QScrollArea > QWidget > QWidget {{ background: {INK}; }}
QScrollBar:vertical {{ background: {INK}; width: 10px; margin: 0; }}
QScrollBar::handle:vertical {{ background: {LINE}; border-radius: 5px; min-height: 30px; }}
QScrollBar::add-line:vertical, QScrollBar::sub-line:vertical {{ height: 0; }}
"""


# --------------------------------------------------------------------------- small helpers
def app_pixmap(size=256):
    pm = QPixmap(size, size)
    pm.fill(Qt.transparent)
    p = QPainter(pm)
    p.setRenderHint(QPainter.Antialiasing)
    p.setPen(Qt.NoPen)
    p.setBrush(QColor(INK))
    p.drawRoundedRect(QRectF(0, 0, size, size), size * 0.22, size * 0.22)
    p.setBrush(Qt.NoBrush)
    p.setPen(QPen(QColor(TEXT), size * 0.05))
    p.drawEllipse(QPointF(size / 2, size / 2), size * 0.34, size * 0.34)
    p.setPen(Qt.NoPen)
    p.setBrush(QColor(TALLY))
    p.drawEllipse(QPointF(size / 2, size / 2), size * 0.21, size * 0.21)
    p.end()
    return pm


class RecordButton(QAbstractButton):
    """The tally light: a ring with a red disc; becomes a square and pulses while recording."""

    def __init__(self):
        super().__init__()
        self.setFixedSize(132, 132)
        self.setCursor(Qt.PointingHandCursor)
        self.state, self.phase = "idle", 0.0
        self.anim = QTimer(self)
        self.anim.timeout.connect(self._tick)

    def set_state(self, s):
        self.state = s
        self.setEnabled(s != "busy")
        self.anim.start(40) if s == "rec" else self.anim.stop()
        self.update()

    def _tick(self):
        self.phase = (self.phase + 0.08) % (2 * math.pi)
        self.update()

    def paintEvent(self, _):
        p = QPainter(self)
        p.setRenderHint(QPainter.Antialiasing)
        c = QPointF(66, 66)
        rec = self.state == "rec"
        if rec:
            p.setPen(Qt.NoPen)
            p.setBrush(QColor(255, 77, 94, int(35 + 30 * math.sin(self.phase))))
            p.drawEllipse(c, 64, 64)
        p.setBrush(Qt.NoBrush)
        p.setPen(QPen(QColor(TALLY if rec else TEXT), 4))
        p.drawEllipse(c, 57, 57)
        p.setPen(Qt.NoPen)
        p.setBrush(QColor(MUTED if self.state == "busy" else TALLY))
        if rec:
            p.drawRoundedRect(QRectF(46, 46, 40, 40), 8, 8)
        else:
            p.drawEllipse(c, 43 if self.underMouse() else 41, 43 if self.underMouse() else 41)


class HotkeyFilter(QAbstractNativeEventFilter):
    """Global Ctrl+Alt+R to start/stop recording from any app."""
    HOTKEY_ID = 0xB35

    def __init__(self, callback):
        super().__init__()
        self.callback = callback
        try:
            ctypes.windll.user32.RegisterHotKey(None, self.HOTKEY_ID, 0x0001 | 0x0002 | 0x4000, ord("R"))
        except Exception:
            pass

    def nativeEventFilter(self, event_type, message):
        try:
            if bytes(event_type) == b"windows_generic_MSG":
                msg = wintypes.MSG.from_address(int(message))
                if msg.message == 0x0312 and msg.wParam == self.HOTKEY_ID:
                    QTimer.singleShot(0, self.callback)
        except Exception:
            pass
        return False, 0


class ProbeWorker(QThread):
    done = Signal(list, list, bool)

    def __init__(self, ff):
        super().__init__()
        self.ff = ff

    def run(self):
        self.done.emit(engine.detect_encoders(self.ff), engine.list_audio_devices(self.ff),
                       engine.has_ddagrab(self.ff))


# --------------------------------------------------------------------------- YouTube dialog
class UploadDialog(QDialog):
    def __init__(self, parent, path, settings):
        super().__init__(parent)
        self.setWindowTitle("Upload to YouTube")
        self.setMinimumWidth(520)
        self.path, self.settings, self.worker = path, settings, None
        lay = QVBoxLayout(self)
        lay.setSpacing(8)
        lay.addWidget(label(Path(path).name, "Muted"))
        self.title = QLineEdit(Path(path).stem.replace("_", " "))
        self.desc = QPlainTextEdit()
        self.desc.setPlaceholderText("Description")
        self.desc.setFixedHeight(110)
        self.tags = QLineEdit()
        self.tags.setPlaceholderText("Tags, separated by commas")
        self.privacy = QComboBox()
        for text, val in (("Private", "private"), ("Unlisted", "unlisted"), ("Public", "public")):
            self.privacy.addItem(text, val)
        self.privacy.setCurrentIndex(max(0, self.privacy.findData(settings["yt_privacy"])))
        for w in (label("Title", "H"), self.title, label("Description", "H"), self.desc,
                  label("Tags", "H"), self.tags, label("Who can watch", "H"), self.privacy):
            lay.addWidget(w)
        self.bar = QProgressBar()
        self.bar.hide()
        self.msg = label("", "Muted")
        self.msg.setOpenExternalLinks(True)
        self.msg.setWordWrap(True)
        lay.addWidget(self.bar)
        lay.addWidget(self.msg)
        row = QHBoxLayout()
        row.addStretch()
        self.close_btn = QPushButton("Close")
        self.close_btn.clicked.connect(self.reject)
        self.go = QPushButton("Upload")
        self.go.setObjectName("Go")
        self.go.clicked.connect(self.start)
        row.addWidget(self.close_btn)
        row.addWidget(self.go)
        lay.addLayout(row)

    def start(self):
        if not youtube.libs_available():
            self.msg.setText("Install the Google libraries first: pip install -r requirements.txt")
            return
        if not youtube.SECRET.exists() and not youtube.is_connected():
            self.msg.setText("Add your Google client_secret.json in Settings, then try again.")
            return
        if not self.title.text().strip():
            self.msg.setText("Give the video a title.")
            return
        tags = [t.strip() for t in self.tags.text().split(",") if t.strip()]
        self.go.setEnabled(False)
        self.bar.show()
        self.msg.setText("Uploading. A browser tab opens the first time so you can sign in.")
        self.worker = youtube.UploadWorker(self.path, self.title.text().strip(), self.desc.toPlainText(),
                                           tags, self.privacy.currentData())
        self.worker.progress.connect(self.bar.setValue)
        self.worker.done.connect(self.finished_ok)
        self.worker.failed.connect(self.finished_err)
        self.worker.start()

    def finished_ok(self, url):
        self.msg.setText(f'Published: <a style="color:{LILAC}" href="{url}">{url}</a>')
        QApplication.clipboard().setText(url)
        self.msg.setToolTip("Link copied to clipboard")

    def finished_err(self, err):
        self.go.setEnabled(True)
        self.bar.hide()
        self.msg.setText(f"Upload failed: {err[:400]}")

    def reject(self):
        if self.worker and self.worker.isRunning():
            return
        super().reject()


# --------------------------------------------------------------------------- main window
class Main(QWidget):
    def __init__(self):
        super().__init__()
        self.setObjectName("Root")
        self.setWindowTitle("BeauShare")
        self.setWindowIcon(QIcon(app_pixmap()))
        self.resize(1260, 800)
        self.s = engine.Settings()
        self.ff = engine.find_ffmpeg()
        self.encoders, self.audio, self.has_dd = [("libx264", "CPU (x264)")], [], False
        self.last_path, self.retried = None, False
        self.rec = engine.Recorder(self.ff) if self.ff else None
        self.mode, self.live, self.live_secrets, self.feeder = "idle", None, [], None
        self.chat = ChatModel()
        self.panels = PanelStore()
        self.twitch = twitch.Auth(self.s)
        self.ptt = PushToTalk(self.rec.send if self.rec else (lambda line: None))
        self.ptt_on = False
        self.build_ui()
        if self.rec:
            self.ptt.live_changed.connect(self.ptt_state)
            self.rec.started.connect(self.on_started)
            self.rec.processing.connect(lambda: self.set_status("Finishing the file…"))
            self.rec.finished.connect(self.on_finished)
            self.rec.failed.connect(self.on_failed)
            self.probe()
        self.tick = QTimer(self)
        self.tick.timeout.connect(self.update_timer)

    # ---- layout
    def build_ui(self):
        root = QHBoxLayout(self)
        root.setContentsMargins(0, 0, 0, 0)
        root.setSpacing(0)
        side = QWidget()
        side.setObjectName("Side")
        side.setFixedWidth(200)
        sl = QVBoxLayout(side)
        sl.setContentsMargins(14, 22, 14, 18)
        sl.setSpacing(4)
        brand = QHBoxLayout()
        logo = QLabel()
        logo.setPixmap(app_pixmap(64).scaled(30, 30, Qt.KeepAspectRatio, Qt.SmoothTransformation))
        brand.addWidget(logo)
        brand.addWidget(label("BeauShare", "Brand"))
        brand.addStretch()
        sl.addLayout(brand)
        sl.addSpacing(18)
        self.stack = QStackedWidget()
        self.navs = []
        for i, name in enumerate(("Record", "Stream", "Panels", "Library", "Editor", "Settings")):
            b = QPushButton(name)
            b.setObjectName("Nav")
            b.setCheckable(True)
            b.clicked.connect(lambda _, i=i: self.goto(i))
            sl.addWidget(b)
            self.navs.append(b)
        sl.addStretch()
        sl.addWidget(label("Ctrl+Alt+R starts and stops", "Hint"))
        root.addWidget(side)
        root.addWidget(self.stack, 1)
        self.stack.addWidget(self.page_record())
        self.stream = StreamPage(self)
        self.stack.addWidget(self.stream)
        self.stack.addWidget(PanelsPage(self))
        self.stack.addWidget(self.page_library())
        self.editor = EditorPage(self)
        self.stack.addWidget(self.editor)
        self.stack.addWidget(self.page_settings())
        self.goto(0)

    def goto(self, i):
        self.stack.setCurrentIndex(i)
        for n, b in enumerate(self.navs):
            b.setChecked(n == i)
        if i == 3:
            self.refresh_library()

    def page_record(self):
        page = QWidget()
        page.setObjectName("Page")
        outer = QVBoxLayout(page)
        outer.setContentsMargins(0, 0, 0, 0)
        # missing-FFmpeg banner
        self.banner = QFrame()
        self.banner.setObjectName("Banner")
        bl = QHBoxLayout(self.banner)
        bl.addWidget(label("BeauShare needs FFmpeg to record. It's free and takes a minute to install."), 1)
        inst = QPushButton("Install FFmpeg")
        inst.setObjectName("Go")
        inst.clicked.connect(self.install_ffmpeg)
        recheck = QPushButton("I installed it")
        recheck.clicked.connect(self.recheck_ffmpeg)
        bl.addWidget(inst)
        bl.addWidget(recheck)
        self.banner.setVisible(self.ff is None)
        wrap = QHBoxLayout()
        wrap.setContentsMargins(24, 20, 24, 0)
        wrap.addWidget(self.banner)
        outer.addLayout(wrap)

        body = QHBoxLayout()
        body.setContentsMargins(0, 0, 0, 0)
        # centre: tally light + timer
        centre = QVBoxLayout()
        centre.setAlignment(Qt.AlignCenter)
        self.status = label("Ready", "Status")
        self.status.setAlignment(Qt.AlignCenter)
        self.timer_lbl = label("00:00:00", "Timer")
        self.timer_lbl.setAlignment(Qt.AlignCenter)
        self.rbtn = RecordButton()
        self.rbtn.clicked.connect(self.toggle)
        self.rbtn.setEnabled(self.ff is not None)
        centre.addStretch(2)
        centre.addWidget(self.timer_lbl)
        centre.addWidget(self.status)
        self.mic_badge = label("", "Status")
        self.mic_badge.setAlignment(Qt.AlignCenter)
        self.mic_badge.hide()
        centre.addWidget(self.mic_badge)
        centre.addSpacing(26)
        centre.addWidget(self.rbtn, 0, Qt.AlignCenter)
        centre.addStretch(2)
        # last recording strip
        self.last_box = QWidget()
        lb = QHBoxLayout(self.last_box)
        lb.setContentsMargins(0, 0, 0, 0)
        self.last_lbl = label("", "Muted")
        lb.addWidget(self.last_lbl, 1)
        for text, fn in (("Play", lambda: os.startfile(self.last_path)),
                         ("Edit", lambda: self.open_editor(self.last_path)),
                         ("Show in folder", lambda: reveal(self.last_path)),
                         ("Upload to YouTube", lambda: self.upload(self.last_path))):
            b = QPushButton(text)
            b.clicked.connect(fn)
            lb.addWidget(b)
        self.last_box.hide()
        centre.addWidget(self.last_box)
        body.addLayout(centre, 1)
        body.setContentsMargins(24, 0, 0, 24)

        # right rail
        rail = QWidget()
        rail.setFixedWidth(330)
        rl = QVBoxLayout(rail)
        rl.setContentsMargins(24, 8, 24, 24)
        rl.setSpacing(8)

        self.monitor = QComboBox()
        for i, sc in enumerate(QApplication.screens()):
            r = sc.geometry()
            d = sc.devicePixelRatio()
            self.monitor.addItem(f"Display {i + 1} ({round(r.width() * d)}×{round(r.height() * d)})",
                                 dict(index=i, x=round(r.x() * d), y=round(r.y() * d),
                                      w=round(r.width() * d) // 2 * 2, h=round(r.height() * d) // 2 * 2))
        self.monitor.setCurrentIndex(min(self.s["monitor"], self.monitor.count() - 1))
        self.res = QComboBox()
        self.res.addItems(["Native", "2160p", "1440p", "1080p", "720p"])
        self.res.setCurrentText(self.s["resolution"])
        self.fps = QComboBox()
        self.fps.addItems(["24", "30", "60", "120"])
        self.fps.setCurrentText(str(self.s["fps"]))
        self.cursor = QCheckBox("Show mouse cursor")
        self.cursor.setChecked(self.s["cursor"])
        self.sys_chk = QCheckBox("Computer sound")
        self.sys_chk.setChecked(self.s["system_audio"])
        self.sys_dev = QComboBox()
        self.mic_chk = QCheckBox("Microphone")
        self.mic_chk.setChecked(self.s["mic_audio"])
        self.mic_dev = QComboBox()
        self.ptt_row = QWidget()
        pr = QHBoxLayout(self.ptt_row)
        pr.setContentsMargins(0, 0, 0, 0)
        self.ptt_chk = QCheckBox("Push to talk")
        self.ptt_chk.setChecked(self.s["ptt"])
        self.ptt_btn = QPushButton(key_name(self.s["ptt_vk"]))
        self.ptt_btn.setToolTip("Click, then press the key or mouse button to hold while you talk")
        self.ptt_btn.clicked.connect(self.capture_ptt_key)
        pr.addWidget(self.ptt_chk)
        pr.addStretch()
        pr.addWidget(self.ptt_btn)
        self.mic_chk.toggled.connect(self.ptt_row.setEnabled)
        self.ptt_row.setEnabled(self.mic_chk.isChecked())
        self.quality = QComboBox()
        self.quality.addItems(list(engine.QUALITY))
        self.quality.setCurrentText(self.s["quality"])
        self.encoder = QComboBox()
        self.encoder.addItem("Auto")

        def section(title, *widgets):
            rl.addWidget(label(title, "H"))
            for w in widgets:
                rl.addWidget(w)
            rl.addSpacing(6)
            rl.addWidget(hline())
            rl.addSpacing(6)

        section("Screen", self.monitor, self.res, self.fps, self.cursor)
        section("Sound", self.sys_chk, self.sys_dev, self.mic_chk, self.mic_dev, self.ptt_row)
        rl.addWidget(label("Quality", "H"))
        rl.addWidget(self.quality)
        rl.addWidget(self.encoder)
        self.sound_hint = label("", "Hint")
        self.sound_hint.setWordWrap(True)
        rl.addWidget(self.sound_hint)
        rl.addStretch()
        body.addWidget(rail)
        outer.addLayout(body, 1)
        return page

    def page_library(self):
        page = QWidget()
        page.setObjectName("Page")
        lay = QVBoxLayout(page)
        lay.setContentsMargins(28, 24, 28, 24)
        lay.addWidget(label("Library", "Brand"))
        self.lib_path = label("", "Muted")
        lay.addWidget(self.lib_path)
        self.lib = QListWidget()
        self.lib.itemDoubleClicked.connect(lambda it: os.startfile(it.data(Qt.UserRole)))
        lay.addWidget(self.lib, 1)
        row = QHBoxLayout()
        for text, fn in (("Play", self.lib_play), ("Edit", self.lib_edit), ("Show in folder", self.lib_reveal),
                         ("Upload to YouTube", self.lib_upload), ("Delete", self.lib_delete)):
            b = QPushButton(text)
            b.clicked.connect(fn)
            row.addWidget(b)
        row.addStretch()
        lay.addLayout(row)
        return page

    def page_settings(self):
        page = QWidget()
        page.setObjectName("Page")
        lay = QVBoxLayout(page)
        lay.setContentsMargins(28, 24, 28, 24)
        lay.setSpacing(8)
        lay.addWidget(label("Settings", "Brand"))

        lay.addWidget(label("Save recordings to", "H"))
        row = QHBoxLayout()
        self.save_edit = QLineEdit(self.s["save_dir"])
        self.save_edit.setReadOnly(True)
        b1 = QPushButton("Change…")
        b1.clicked.connect(self.pick_save_dir)
        b2 = QPushButton("Open")
        b2.clicked.connect(lambda: self.open_dir(self.s["save_dir"]))
        for w in (self.save_edit, b1, b2):
            row.addWidget(w)
        lay.addLayout(row)

        lay.addWidget(label("Also copy every recording to", "H"))
        self.copy_list = QListWidget()
        self.copy_list.setFixedHeight(96)
        self.copy_list.addItems(self.s["copy_dirs"])
        lay.addWidget(self.copy_list)
        row = QHBoxLayout()
        add = QPushButton("Add folder…")
        add.clicked.connect(self.add_copy_dir)
        rem = QPushButton("Remove")
        rem.clicked.connect(self.remove_copy_dir)
        row.addWidget(add)
        row.addWidget(rem)
        row.addStretch()
        lay.addLayout(row)

        lay.addWidget(label("File name", "H"))
        self.name_edit = QLineEdit(self.s["filename_template"])
        self.name_edit.textChanged.connect(self.name_changed)
        self.name_prev = label("", "Hint")
        lay.addWidget(self.name_edit)
        lay.addWidget(self.name_prev)
        self.name_changed(self.name_edit.text())

        self.hide_chk = QCheckBox("Keep BeauShare out of recordings")
        self.hide_chk.setChecked(self.s["hide_self"])
        self.hide_chk.toggled.connect(lambda v: (self.s.__setitem__("hide_self", v), self.apply_affinity()))
        self.mkv_chk = QCheckBox("Keep the working .mkv file after converting to MP4")
        self.mkv_chk.setChecked(self.s["keep_mkv"])
        self.mkv_chk.toggled.connect(lambda v: self.s.__setitem__("keep_mkv", v))
        lay.addSpacing(6)
        lay.addWidget(self.hide_chk)
        lay.addWidget(self.mkv_chk)

        lay.addSpacing(6)
        lay.addWidget(hline())
        lay.addWidget(label("YouTube", "H"))
        self.yt_state = label("", "Muted")
        self.yt_state.setWordWrap(True)
        lay.addWidget(self.yt_state)
        row = QHBoxLayout()
        self.yt_import = QPushButton("Add client_secret.json…")
        self.yt_import.clicked.connect(self.import_secret)
        self.yt_in = QPushButton("Sign in")
        self.yt_in.clicked.connect(self.sign_in)
        self.yt_out = QPushButton("Sign out")
        self.yt_out.clicked.connect(lambda: (youtube.disconnect(), self.refresh_yt()))
        for w in (self.yt_import, self.yt_in, self.yt_out):
            row.addWidget(w)
        row.addStretch()
        lay.addLayout(row)
        lay.addWidget(label("One-time setup: in Google Cloud Console, enable the YouTube Data API v3 and create an "
                            "OAuth client of type Desktop app. Download its JSON and add it here. See the README.",
                            "Hint"))
        lay.itemAt(lay.count() - 1).widget().setWordWrap(True)
        lay.addStretch()
        self.refresh_yt()
        return page

    # ---- probing / ffmpeg
    def probe(self):
        self.set_status("Checking your graphics hardware…")
        self.rbtn.set_state("busy")
        self.pw = ProbeWorker(self.ff)
        self.pw.done.connect(self.probed)
        self.pw.start()

    def probed(self, encoders, audio, has_dd):
        self.encoders, self.audio, self.has_dd = encoders, audio, has_dd
        self.encoder.clear()
        self.encoder.addItem("Auto")
        for enc, name in encoders:
            self.encoder.addItem(name, enc)
        self.encoder.setCurrentText(self.s["encoder"]) if self.encoder.findText(self.s["encoder"]) >= 0 else None
        for combo, key in ((self.sys_dev, "system_device"), (self.mic_dev, "mic_device")):
            combo.clear()
            combo.addItems(audio)
            if self.s[key] in audio:
                combo.setCurrentText(self.s[key])
        # guess sensible defaults
        if not self.s["system_device"]:
            for d in audio:
                if re.search(r"stereo mix|loopback|virtual-audio|cable|what u hear", d, re.I):
                    self.sys_dev.setCurrentText(d)
        if not audio:
            self.sound_hint.setText("No audio devices were found.")
        elif not any(re.search(r"stereo mix|loopback|virtual-audio|cable", d, re.I) for d in audio):
            self.sound_hint.setText("To capture computer sound, enable “Stereo Mix” in Windows Sound settings "
                                    "(Recording tab) or install a virtual audio cable, then restart BeauShare.")
        self.rbtn.set_state("idle")
        self.set_status("Ready")

    def install_ffmpeg(self):
        import shutil
        import webbrowser
        if not shutil.which("winget"):
            QMessageBox.information(self, "BeauShare", "winget isn't available on this PC, so I'll open the "
                                    "FFmpeg download page. Download the \"release essentials\" zip, then copy "
                                    "ffmpeg.exe (from its bin folder) next to BeauShare and reopen the app.")
            webbrowser.open("https://www.gyan.dev/ffmpeg/builds/")
            return
        # No shell=True: that hides the new console window.
        subprocess.Popen(["cmd.exe", "/k", "winget install --id Gyan.FFmpeg -e "
                          "--accept-source-agreements --accept-package-agreements"],
                         creationflags=0x00000010)  # CREATE_NEW_CONSOLE
        QMessageBox.information(self, "BeauShare", "A black installer window just opened. When it says the "
                                "install finished, close it and click “I installed it”.")

    def recheck_ffmpeg(self):
        if engine.find_ffmpeg():
            QMessageBox.information(self, "BeauShare", "FFmpeg found. BeauShare will restart.")
            subprocess.Popen([sys.executable] + (sys.argv[1:] if getattr(sys, "frozen", False) else sys.argv))
            QApplication.quit()
        else:
            QMessageBox.warning(self, "BeauShare", "FFmpeg still isn't found. Finish the install, "
                                "then close and reopen BeauShare.")

    # ---- recording
    def toggle(self):
        if not self.rec:
            return
        if self.mode == "live":
            self.set_status("You're live. Stop streaming from the Stream tab.")
        elif self.rec.active:
            self.ptt.stop()
            self.mic_badge.hide()
            self.rbtn.set_state("busy")
            self.rec.stop()
        else:
            self.retried, self.live, self.live_secrets = False, None, []
            self.set_mode("record")
            self.begin(force_gdi=False)

    def set_mode(self, mode):
        self.mode = mode
        self.stream.refresh_state()

    def start_live(self, cfg, secrets):
        self.live, self.live_secrets, self.retried = cfg, secrets, False
        self.set_mode("live")
        self.begin(force_gdi=False)

    def stop_capture(self):
        if self.rec and self.rec.active:
            self.ptt.stop()
            self.mic_badge.hide()
            self.stream.go.setEnabled(False)
            self.stream.state.setText("Ending stream…")
            self.rec.stop()

    def stop_feeder(self):
        if self.feeder:
            self.feeder.stop()
            self.feeder = None

    def panel_ctx(self):
        t = int(self.rec.elapsed()) if self.rec else 0
        v = self.stream.viewers if hasattr(self, "stream") else None
        now = datetime.now()
        return {"tokens": {"uptime": f"{t // 3600:02d}:{t % 3600 // 60:02d}:{t % 60:02d}",
                           "time": now.strftime("%H:%M"), "date": now.strftime("%d %b %Y"),
                           "viewers": "-" if v is None else v, "title": self.s["stream_title"]},
                "model": self.chat}

    def chosen_encoder(self):
        return self.encoder.currentData() if self.encoder.currentIndex() > 0 else self.encoders[0][0]

    def begin(self, force_gdi):
        if not self._begin(force_gdi):
            self.set_mode("idle")

    def _begin(self, force_gdi):
        enc = self.chosen_encoder()
        audio, ptt_pos = [], None
        if self.sys_chk.isChecked() and self.sys_dev.currentText():
            audio.append(self.sys_dev.currentText())
        if self.mic_chk.isChecked() and self.mic_dev.currentText():
            audio.append(self.mic_dev.currentText())
            if self.ptt_chk.isChecked():
                ptt_pos = len(audio) - 1
        self.ptt_on = ptt_pos is not None
        if (self.sys_chk.isChecked() or self.mic_chk.isChecked()) and not audio:
            QMessageBox.information(self, "BeauShare", "Choose an audio device, or turn off sound.")
            return
        opts = dict(fps=self.fps.currentText(), resolution=self.res.currentText(),
                    quality=self.quality.currentText(), cursor=self.cursor.isChecked(), audio=audio,
                    ptt_pos=ptt_pos)
        self.save_prefs()
        folder = Path(self.s["save_dir"])
        try:
            folder.mkdir(parents=True, exist_ok=True)
        except Exception as e:
            QMessageBox.warning(self, "BeauShare", f"Can't use the save folder:\n{e}")
            return
        stem = safe_name(datetime.now().strftime(self.s["filename_template"]))
        n, base = 1, stem
        while (folder / f"{stem}.mp4").exists() or (folder / f"{stem}.mkv").exists():
            n += 1
            stem = f"{base}_{n}"
        self.use_dd = self.has_dd and not force_gdi
        tmp, final = str(folder / f"{stem}.mkv"), str(folder / f"{stem}.mp4")
        live = self.live
        record = live is None or live["record"]
        panels_on = bool(self.panels.enabled()) and (live is not None or self.s["panels_in_recording"])
        self.stop_feeder()
        overlay = None
        if panels_on:
            self.feeder = OverlayFeeder(self.panels, self.panel_ctx)
            overlay = dict(args=self.feeder.input_args(), rec=bool(self.s["panels_in_recording"] and record))
        if live is None and not panels_on:
            args = engine.build_command(self.ff, tmp, enc, opts, self.monitor.currentData(), self.use_dd)
        else:
            args = engine.build_command2(self.ff, enc, opts, self.monitor.currentData(), self.use_dd,
                                         rec_out=tmp if record else None, stream=live, overlay=overlay)
        try:
            self.rec.start(args, tmp, final, self.s["copy_dirs"], self.s["keep_mkv"], record=record,
                           secrets=self.live_secrets)
            if self.feeder:
                self.feeder.start()
            return True
        except Exception as e:
            self.stop_feeder()
            QMessageBox.warning(self, "BeauShare", f"Couldn't start FFmpeg:\n{e}")
            return False

    def on_started(self):
        live = self.mode == "live"
        self.rbtn.set_state("busy" if live else "rec")
        self.set_status("Live" if live else "Recording")
        self.tick.start(250)
        if self.ptt_on:
            self.ptt.start(self.s["ptt_vk"])
            self.ptt_state(False)
            self.mic_badge.show()
        self.setWindowTitle("BeauShare (LIVE)" if live else "BeauShare (recording)")
        self.apply_affinity()

    def update_timer(self):
        t = int(self.rec.elapsed())
        self.timer_lbl.setText(f"{t // 3600:02d}:{t % 3600 // 60:02d}:{t % 60:02d}")

    def on_finished(self, path, warnings):
        self.tick.stop()
        self.ptt.stop()
        self.stop_feeder()
        self.mic_badge.hide()
        self.rbtn.set_state("idle")
        self.setWindowTitle("BeauShare")
        self.set_mode("idle")
        if not path:
            self.set_status("Stream ended")
            return
        self.last_path = path
        self.last_lbl.setText(f"Saved {Path(path).name} ({human_size(os.path.getsize(path))})")
        self.last_box.show()
        self.set_status("Saved")
        if warnings:
            QMessageBox.warning(self, "BeauShare", "\n".join(warnings))

    def on_failed(self, log):
        self.tick.stop()
        self.ptt.stop()
        self.stop_feeder()
        self.mic_badge.hide()
        quick = time.time() - self.rec.t0 < 6
        if (self.use_dd and quick and not self.retried and not self.rec._stopping
                and "rtmp" not in log.lower()):
            self.retried = True
            self.begin(force_gdi=True)  # fall back to the older capture method
            return
        self.rbtn.set_state("idle")
        self.setWindowTitle("BeauShare")
        self.set_mode("idle")
        self.set_status("Something went wrong")
        QMessageBox.critical(self, "Recording failed", log[-900:] or "Unknown error.")

    def set_status(self, t):
        self.status.setText(t)

    # ---- push to talk
    def capture_ptt_key(self):
        self.ptt_btn.setText("Press a key…")
        self.kc = KeyCapture()
        self.kc.captured.connect(self.ptt_captured)
        self.kc.start()

    def ptt_captured(self, vk):
        if vk:
            self.s["ptt_vk"] = vk
        self.ptt_btn.setText(key_name(self.s["ptt_vk"]))

    def ptt_state(self, live):
        key = key_name(self.s["ptt_vk"])
        self.mic_badge.setText("Mic live" if live else f"Mic muted. Hold {key} to talk")
        self.mic_badge.setStyleSheet(f"color: {TALLY if live else MUTED};")

    # ---- editor
    def open_editor(self, path):
        if path and os.path.exists(path):
            self.editor.load(path)
            self.goto(4)

    def lib_edit(self):
        self.open_editor(self.lib_selected())

    # ---- library
    def refresh_library(self):
        folder = Path(self.s["save_dir"])
        self.lib_path.setText(str(folder))
        self.lib.clear()
        files = []
        if folder.exists():
            files = sorted((f for f in folder.iterdir() if f.suffix.lower() in (".mp4", ".mkv")),
                           key=lambda f: f.stat().st_mtime, reverse=True)
        if not files:
            self.lib.addItem("No recordings yet. Press the red button on Record to make your first one.")
            self.lib.item(0).setFlags(Qt.NoItemFlags)
        for f in files:
            st = f.stat()
            it = QListWidgetItem(f"{f.name}\n{human_size(st.st_size)} · "
                                 f"{datetime.fromtimestamp(st.st_mtime):%d %b %Y, %H:%M}")
            it.setData(Qt.UserRole, str(f))
            self.lib.addItem(it)

    def lib_selected(self):
        it = self.lib.currentItem()
        return it.data(Qt.UserRole) if it else None

    def lib_play(self):
        p = self.lib_selected()
        p and os.startfile(p)

    def lib_reveal(self):
        p = self.lib_selected()
        p and reveal(p)

    def lib_upload(self):
        p = self.lib_selected()
        p and self.upload(p)

    def lib_delete(self):
        p = self.lib_selected()
        if p and QMessageBox.question(self, "Delete recording",
                                      f"Delete {Path(p).name}? This can't be undone.") == QMessageBox.Yes:
            try:
                os.remove(p)
            except Exception as e:
                QMessageBox.warning(self, "BeauShare", str(e))
            self.refresh_library()

    def upload(self, path):
        if path and os.path.exists(path):
            UploadDialog(self, path, self.s).exec()

    # ---- settings actions
    def save_prefs(self):
        self.s.data.update(monitor=self.monitor.currentIndex(), resolution=self.res.currentText(),
                           fps=int(self.fps.currentText()), cursor=self.cursor.isChecked(),
                           system_audio=self.sys_chk.isChecked(), system_device=self.sys_dev.currentText(),
                           mic_audio=self.mic_chk.isChecked(), mic_device=self.mic_dev.currentText(),
                           quality=self.quality.currentText(), encoder=self.encoder.currentText(),
                           ptt=self.ptt_chk.isChecked())
        self.s.save()

    def open_dir(self, d):
        Path(d).mkdir(parents=True, exist_ok=True)
        os.startfile(d)

    def pick_save_dir(self):
        d = QFileDialog.getExistingDirectory(self, "Save recordings to", self.s["save_dir"])
        if d:
            self.s["save_dir"] = os.path.normpath(d)
            self.save_edit.setText(self.s["save_dir"])

    def add_copy_dir(self):
        d = QFileDialog.getExistingDirectory(self, "Also copy recordings to")
        if d and os.path.normpath(d) not in self.s["copy_dirs"]:
            self.s["copy_dirs"] = self.s["copy_dirs"] + [os.path.normpath(d)]
            self.copy_list.addItem(os.path.normpath(d))

    def remove_copy_dir(self):
        row = self.copy_list.currentRow()
        if row >= 0:
            dirs = list(self.s["copy_dirs"])
            dirs.pop(row)
            self.s["copy_dirs"] = dirs
            self.copy_list.takeItem(row)

    def name_changed(self, text):
        self.s["filename_template"] = text or "BeauShare_%Y-%m-%d_%H-%M-%S"
        try:
            self.name_prev.setText("Example: " + safe_name(datetime.now().strftime(self.s["filename_template"])) + ".mp4")
        except Exception:
            self.name_prev.setText("That pattern isn't valid.")

    def apply_affinity(self):
        """Exclude this window from screen capture (Windows 10 2004+ / Windows 11)."""
        try:
            ctypes.windll.user32.SetWindowDisplayAffinity(int(self.winId()), 0x11 if self.s["hide_self"] else 0)
        except Exception:
            pass

    def refresh_yt(self):
        if not youtube.libs_available():
            self.yt_state.setText("Google libraries aren't installed. Run: pip install -r requirements.txt")
        elif youtube.is_connected():
            self.yt_state.setText("Signed in to YouTube. You're ready to upload.")
        elif youtube.SECRET.exists():
            self.yt_state.setText("client_secret.json added. Sign in to finish.")
        else:
            self.yt_state.setText("Not set up yet.")
        self.yt_in.setEnabled(youtube.libs_available() and youtube.SECRET.exists() and not youtube.is_connected())
        self.yt_out.setEnabled(youtube.is_connected())

    def import_secret(self):
        f, _ = QFileDialog.getOpenFileName(self, "Choose client_secret.json", "", "JSON (*.json)")
        if f:
            youtube.import_client_secret(f)
            self.refresh_yt()

    def sign_in(self):
        self.yt_state.setText("Finish signing in from the browser tab that just opened…")
        self.sw = youtube.SignInWorker()
        self.sw.done.connect(self.refresh_yt)
        self.sw.failed.connect(lambda e: (self.refresh_yt(), QMessageBox.warning(self, "YouTube", e[:500])))
        self.sw.start()

    def showEvent(self, e):
        super().showEvent(e)
        self.apply_affinity()

    def closeEvent(self, e):
        if self.rec and self.rec.active:
            QMessageBox.information(self, "BeauShare", "Stop recording or streaming before closing BeauShare.")
            e.ignore()
            return
        self.save_prefs()
        e.accept()


def main():
    try:
        ctypes.windll.shell32.SetCurrentProcessExplicitAppUserModelID("BeauShare.Recorder")
    except Exception:
        pass
    app = QApplication(sys.argv)
    app.setStyleSheet(QSS)
    app.setFont(QFont("Segoe UI Variable Text", 10))
    w = Main()
    hk = HotkeyFilter(w.toggle)
    app.installNativeEventFilter(hk)
    w.show()
    sys.exit(app.exec())


if __name__ == "__main__":
    main()
