@echo off
setlocal EnableExtensions
title BeauShare installer
cd /d "%~dp0"
echo.
echo  BeauShare 2 installer (builds the app on this PC; first run takes 5-10 minutes)
echo.
call "%~dp0build_app.bat"
if errorlevel 2 goto :restart
if errorlevel 1 goto :fail

echo.
echo Installing...
set "DEST=%LOCALAPPDATA%\Programs\BeauShare"
robocopy "dist\BeauShare" "%DEST%" /MIR /NFL /NDL /NJH /NJS /NP >nul
if errorlevel 8 goto :fail
powershell -NoProfile -ExecutionPolicy Bypass -Command "$w=New-Object -ComObject WScript.Shell; foreach($d in @([Environment]::GetFolderPath('Desktop'),[Environment]::GetFolderPath('Programs'))){ $s=$w.CreateShortcut($d+'\BeauShare.lnk'); $s.TargetPath='%DEST%\BeauShare.exe'; $s.WorkingDirectory='%DEST%'; $s.Save() }"
echo.
echo  Done! BeauShare is installed and there is a shortcut on your Desktop.
start "" "%DEST%\BeauShare.exe"
pause
exit /b 0

:restart
echo.
echo Python is installed. Please CLOSE this window and run this file again.
pause
exit /b 1

:fail
echo.
echo Something went wrong. Scroll up to see the error, and send it to me if you're stuck.
pause
exit /b 1
