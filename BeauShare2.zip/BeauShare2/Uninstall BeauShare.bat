@echo off
echo Removing BeauShare...
rmdir /s /q "%LOCALAPPDATA%\Programs\BeauShare"
powershell -NoProfile -Command "Remove-Item ([Environment]::GetFolderPath('Desktop')+'\BeauShare.lnk'),([Environment]::GetFolderPath('Programs')+'\BeauShare.lnk') -ErrorAction SilentlyContinue"
echo Done. Your settings and recordings were kept (settings: %APPDATA%\BeauShare).
pause
