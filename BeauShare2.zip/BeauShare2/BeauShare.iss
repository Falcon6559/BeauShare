; Inno Setup script for BeauShare. Build with "Build Setup Wizard.bat" (or open in Inno Setup and press Compile).
#define AppName "BeauShare"
#define AppVersion "2.0.0"

[Setup]
AppId={{D11252F7-5327-4F6A-A327-819F7D408A5E}
AppName={#AppName}
AppVersion={#AppVersion}
AppPublisher=BeauShare
DefaultDirName={autopf}\{#AppName}
DefaultGroupName={#AppName}
DisableProgramGroupPage=yes
OutputDir=Output
OutputBaseFilename=BeauShareSetup
#ifexist "icon.ico"
SetupIconFile=icon.ico
#endif
UninstallDisplayIcon={app}\BeauShare.exe
InfoBeforeFile=NOTICES.txt
Compression=lzma2/max
SolidCompression=yes
WizardStyle=modern
PrivilegesRequired=lowest
PrivilegesRequiredOverridesAllowed=dialog
ArchitecturesAllowed=x64compatible
ArchitecturesInstallIn64BitMode=x64compatible
CloseApplications=yes

[Languages]
Name: "english"; MessagesFile: "compiler:Default.isl"

[Tasks]
Name: "desktopicon"; Description: "Create a &desktop shortcut"; GroupDescription: "Shortcuts:"

[Files]
Source: "dist\BeauShare\*"; DestDir: "{app}"; Flags: ignoreversion recursesubdirs createallsubdirs

[Icons]
Name: "{group}\BeauShare"; Filename: "{app}\BeauShare.exe"
Name: "{group}\Uninstall BeauShare"; Filename: "{uninstallexe}"
Name: "{autodesktop}\BeauShare"; Filename: "{app}\BeauShare.exe"; Tasks: desktopicon

[Run]
Filename: "{app}\BeauShare.exe"; Description: "Launch BeauShare"; Flags: nowait postinstall skipifsilent

[Code]
procedure CurUninstallStepChanged(CurUninstallStep: TUninstallStep);
begin
  if CurUninstallStep = usPostUninstall then
    if MsgBox('Also delete your BeauShare settings and saved panels?' + #13#10 +
              '(Your recordings are never touched.)', mbConfirmation, MB_YESNO or MB_DEFBUTTON2) = IDYES then
      DelTree(ExpandConstant('{userappdata}\BeauShare'), True, True, True);
end;
