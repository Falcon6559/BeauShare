"""YouTube sign-in and resumable upload for BeauShare."""
import os
import random
import shutil
import time

from PySide6.QtCore import QThread, Signal

from engine import APPDATA

SCOPES = ["https://www.googleapis.com/auth/youtube.upload"]
TOKEN = APPDATA / "youtube_token.json"
SECRET = APPDATA / "client_secret.json"


def libs_available():
    try:
        import googleapiclient, google_auth_oauthlib  # noqa: F401
        return True
    except ImportError:
        return False


def import_client_secret(path):
    shutil.copy2(path, SECRET)


def is_connected():
    return TOKEN.exists()


def disconnect():
    try:
        TOKEN.unlink()
    except FileNotFoundError:
        pass


def get_credentials(interactive=True):
    from google.auth.transport.requests import Request
    from google.oauth2.credentials import Credentials
    from google_auth_oauthlib.flow import InstalledAppFlow

    creds = None
    if TOKEN.exists():
        creds = Credentials.from_authorized_user_file(str(TOKEN), SCOPES)
    if creds and creds.expired and creds.refresh_token:
        try:
            creds.refresh(Request())
        except Exception:
            creds = None
    if not creds or not creds.valid:
        if not interactive:
            raise RuntimeError("Not signed in to YouTube.")
        if not SECRET.exists():
            raise RuntimeError("Add your Google client_secret.json in Settings first.")
        flow = InstalledAppFlow.from_client_secrets_file(str(SECRET), SCOPES)
        creds = flow.run_local_server(port=0, prompt="consent",
                                      authorization_prompt_message="",
                                      success_message="BeauShare is connected. You can close this tab.")
    TOKEN.write_text(creds.to_json(), "utf-8")
    return creds


class SignInWorker(QThread):
    done = Signal()
    failed = Signal(str)

    def run(self):
        try:
            get_credentials(True)
            self.done.emit()
        except Exception as e:
            self.failed.emit(str(e))


class UploadWorker(QThread):
    progress = Signal(int)
    done = Signal(str)
    failed = Signal(str)

    def __init__(self, path, title, description, tags, privacy):
        super().__init__()
        self.path, self.title, self.description = path, title, description
        self.tags, self.privacy = tags, privacy

    def run(self):
        try:
            from googleapiclient.discovery import build
            from googleapiclient.errors import HttpError
            from googleapiclient.http import MediaFileUpload

            yt = build("youtube", "v3", credentials=get_credentials(True), cache_discovery=False)
            body = {
                "snippet": {"title": self.title[:100], "description": self.description,
                            "tags": self.tags, "categoryId": "22"},
                "status": {"privacyStatus": self.privacy, "selfDeclaredMadeForKids": False},
            }
            media = MediaFileUpload(self.path, chunksize=8 * 1024 * 1024, resumable=True)
            req = yt.videos().insert(part="snippet,status", body=body, media_body=media)
            response, retries = None, 0
            while response is None:
                try:
                    status, response = req.next_chunk()
                    if status:
                        self.progress.emit(int(status.progress() * 100))
                    retries = 0
                except HttpError as e:
                    if e.resp.status in (500, 502, 503, 504) and retries < 8:
                        retries += 1
                        time.sleep(min(60, random.random() * 2 ** retries))
                    else:
                        raise
            self.progress.emit(100)
            self.done.emit(f"https://youtu.be/{response['id']}")
        except Exception as e:
            self.failed.emit(str(e))
