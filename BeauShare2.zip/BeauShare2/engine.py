"""BeauShare engine: settings, FFmpeg discovery, encoder detection and the recorder."""
import collections
import json
import os
import re
import shutil
import subprocess
import sys
import threading
import time
from pathlib import Path

from PySide6.QtCore import QObject, QThread, QTimer, Signal

APP_NAME = "BeauShare"
APPDATA = Path(os.environ.get("APPDATA", str(Path.home()))) / APP_NAME
APPDATA.mkdir(parents=True, exist_ok=True)
NO_WINDOW = 0x08000000 if os.name == "nt" else 0

# --------------------------------------------------------------------------- settings
DEFAULTS = {
    "save_dir": str(Path.home() / "Videos" / APP_NAME),
    "copy_dirs": [],
    "filename_template": "BeauShare_%Y-%m-%d_%H-%M-%S",
    "monitor": 0,
    "fps": 60,
    "resolution": "Native",
    "quality": "High",
    "encoder": "Auto",
    "cursor": True,
    "system_audio": False,
    "system_device": "",
    "mic_audio": False,
    "ptt": False,
    "ptt_vk": 0xA3,
    "mic_device": "",
    "hide_self": True,
    "keep_mkv": False,
    "twitch_client_id": "",
    "twitch_channel": "",
    "stream_twitch": True,
    "stream_youtube": False,
    "stream_rtmps": True,
    "stream_bitrate": 6000,
    "stream_res": "1080p",
    "stream_fps": 30,
    "stream_record": True,
    "stream_title": "",
    "panels_in_recording": True,
    "yt_privacy": "private",
    "yt_client_secret": "",
}


class Settings:
    path = APPDATA / "settings.json"

    def __init__(self):
        self.data = dict(DEFAULTS)
        try:
            self.data.update(json.loads(self.path.read_text("utf-8")))
        except Exception:
            pass

    def __getitem__(self, k):
        return self.data.get(k, DEFAULTS.get(k))

    def __setitem__(self, k, v):
        self.data[k] = v
        self.save()

    def save(self):
        try:
            self.path.write_text(json.dumps(self.data, indent=2), "utf-8")
        except Exception:
            pass


# --------------------------------------------------------------------------- ffmpeg helpers
def _run(args, timeout=20):
    return subprocess.run(
        args, capture_output=True, text=True, encoding="utf-8", errors="replace",
        timeout=timeout, creationflags=NO_WINDOW,
    )


def find_ffmpeg():
    base = Path(getattr(sys, "_MEIPASS", Path(__file__).parent))
    local = os.environ.get("LOCALAPPDATA", "")
    candidates = [
        Path(sys.executable).parent / "ffmpeg.exe",
        base / "ffmpeg.exe",
        base / "ffmpeg" / "ffmpeg.exe",
        Path(local) / "Microsoft" / "WinGet" / "Links" / "ffmpeg.exe",
    ]
    for c in candidates:
        if c.exists():
            return str(c)
    return shutil.which("ffmpeg")


ENCODERS = [
    ("h264_nvenc", "NVIDIA NVENC"),
    ("h264_amf", "AMD AMF"),
    ("h264_qsv", "Intel Quick Sync"),
    ("libx264", "CPU (x264)"),
]


def detect_encoders(ff):
    """Return the H.264 encoders that actually work on this PC (tested with a tiny encode)."""
    try:
        listing = _run([ff, "-hide_banner", "-encoders"]).stdout
    except Exception:
        return [("libx264", "CPU (x264)")]
    found = []
    for enc, label in ENCODERS:
        if enc not in listing:
            continue
        if enc == "libx264":
            found.append((enc, label))
            continue
        try:
            r = _run([ff, "-hide_banner", "-loglevel", "error", "-f", "lavfi", "-i",
                      "color=c=black:s=640x360:r=30:d=0.3", "-pix_fmt", "nv12",
                      "-c:v", enc, "-f", "null", "-"], timeout=15)
            if r.returncode == 0:
                found.append((enc, label))
        except Exception:
            pass
    return found or [("libx264", "CPU (x264)")]


def has_ddagrab(ff):
    try:
        return "ddagrab" in _run([ff, "-hide_banner", "-filters"]).stdout
    except Exception:
        return False


def list_audio_devices(ff):
    """DirectShow audio devices (microphones, Stereo Mix, virtual cables...)."""
    try:
        text = _run([ff, "-hide_banner", "-list_devices", "true", "-f", "dshow", "-i", "dummy"]).stderr
    except Exception:
        return []
    devices, in_audio = [], False
    for line in text.splitlines():
        m = re.search(r'"([^"]+)"\s+\(audio\)', line)
        if m:
            devices.append(m.group(1))
            continue
        if "DirectShow audio devices" in line:
            in_audio = True
        elif "DirectShow video devices" in line:
            in_audio = False
        elif in_audio and "Alternative name" not in line:
            m = re.search(r'"([^"]+)"', line)
            if m:
                devices.append(m.group(1))
    return list(dict.fromkeys(devices))


QUALITY = {  # preset -> per-encoder args
    "Balanced": {"nv": ("p4", 23), "q": 24, "crf": 22, "x": "veryfast", "ab": "160k"},
    "High": {"nv": ("p5", 19), "q": 20, "crf": 18, "x": "veryfast", "ab": "192k"},
    "Ultra": {"nv": ("p7", 15), "q": 16, "crf": 14, "x": "faster", "ab": "256k"},
}


def encoder_args(enc, quality):
    q = QUALITY[quality]
    if enc == "h264_nvenc":
        return ["-c:v", enc, "-preset", q["nv"][0], "-tune", "hq", "-rc", "vbr", "-cq", str(q["nv"][1]),
                "-b:v", "0", "-profile:v", "high"]
    if enc == "h264_amf":
        return ["-c:v", enc, "-quality", "quality", "-rc", "cqp", "-qp_i", str(q["q"]),
                "-qp_p", str(q["q"]), "-qp_b", str(q["q"])]
    if enc == "h264_qsv":
        return ["-c:v", enc, "-preset", "slow", "-global_quality", str(q["q"])]
    return ["-c:v", "libx264", "-preset", q["x"], "-crf", str(q["crf"]), "-profile:v", "high"]


def probe_media(ff, path):
    """Duration (seconds), frame rate and whether there is an audio track."""
    try:
        text = _run([ff, "-hide_banner", "-i", path]).stderr
    except Exception:
        text = ""
    m = re.search(r"Duration:\s*(\d+):(\d+):(\d+(?:\.\d+)?)", text)
    dur = int(m[1]) * 3600 + int(m[2]) * 60 + float(m[3]) if m else 0.0
    f = re.search(r"([\d.]+) fps", text)
    return {"duration": dur, "fps": float(f[1]) if f else 30.0,
            "audio": bool(re.search(r"Stream #\d+:\d+.*: Audio", text))}


def build_command(ff, out, enc, o, monitor, use_dd):
    """o = dict with fps, resolution, quality, cursor, audio (list of device names)."""
    fps = int(o["fps"])
    q = QUALITY[o["quality"]]
    a = [ff, "-hide_banner", "-nostats", "-loglevel", "warning", "-y"]

    if use_dd:
        graph = f"ddagrab=output_idx={monitor['index']}:framerate={fps}:draw_mouse={int(o['cursor'])},hwdownload,format=bgra"
        a += ["-f", "lavfi", "-i", graph]
    else:
        a += ["-f", "gdigrab", "-framerate", str(fps), "-draw_mouse", str(int(o["cursor"])),
              "-offset_x", str(monitor["x"]), "-offset_y", str(monitor["y"]),
              "-video_size", f"{monitor['w']}x{monitor['h']}", "-i", "desktop"]

    for dev in o["audio"]:
        a += ["-f", "dshow", "-thread_queue_size", "1024", "-audio_buffer_size", "80",
              "-use_wallclock_as_timestamps", "1", "-i", f"audio={dev}"]

    res = o["resolution"]
    size = "iw:ih" if res == "Native" else f"-2:{res.rstrip('p')}"
    pix = "yuv420p" if enc == "libx264" else "nv12"
    a += ["-vf", f"scale={size}:flags=lanczos:out_color_matrix=bt709:out_range=tv,format={pix}"]

    n, mp = len(o["audio"]), o.get("ptt_pos")
    if n:
        parts, labels = [], []
        for i in range(n):
            if i == mp:  # push-to-talk mic starts muted; the app un-mutes it live via a filter command
                parts.append(f"[{i + 1}:a]volume=0[a{i}]")
                labels.append(f"[a{i}]")
            else:
                labels.append(f"[{i + 1}:a]")
        tail = "amix=inputs=2:duration=longest:normalize=0," if n == 2 else ""
        parts.append("".join(labels) + tail + "aresample=async=1:first_pts=0[aout]")
        a += ["-filter_complex", ";".join(parts), "-map", "0:v", "-map", "[aout]"]
    else:
        a += ["-map", "0:v"]

    a += encoder_args(enc, o["quality"])

    a += ["-g", str(fps * 2), "-colorspace", "bt709", "-color_primaries", "bt709",
          "-color_trc", "bt709", "-color_range", "tv"]
    if o["audio"]:
        a += ["-c:a", "aac", "-b:a", q["ab"], "-ar", "48000"]
    a.append(out)
    return a


def out_size(monitor, res):
    """Even output size for a resolution label such as 'Native' or '1080p'."""
    w, h = monitor["w"], monitor["h"]
    if res == "Native":
        return w // 2 * 2, h // 2 * 2
    oh = int(res.rstrip("p"))
    return round(w * oh / h / 2) * 2, oh // 2 * 2


def stream_encoder_args(enc, kbps):
    """Constant-bitrate H.264 settings, as Twitch and YouTube expect."""
    rate = ["-b:v", f"{kbps}k", "-maxrate", f"{kbps}k", "-bufsize", f"{kbps * 2}k"]
    if enc == "h264_nvenc":
        return ["-c:v", enc, "-preset", "p5", "-tune", "hq", "-rc", "cbr", "-profile:v", "high", "-bf", "2"] + rate
    if enc == "h264_amf":
        return ["-c:v", enc, "-quality", "quality", "-rc", "cbr", "-profile:v", "high"] + rate
    if enc == "h264_qsv":
        return ["-c:v", enc, "-preset", "medium", "-profile:v", "high", "-look_ahead", "0"] + rate
    return ["-c:v", "libx264", "-preset", "veryfast", "-profile:v", "high",
            "-x264-params", "nal-hrd=cbr:force-cfr=1"] + rate


def build_command2(ff, enc, o, monitor, use_dd, rec_out=None, stream=None, overlay=None):
    """Capture once, then fan out to a recording file and/or live stream, with optional panel overlay.

    stream  = dict(urls=[...], bitrate=kbps, resolution='1080p', fps=30)
    overlay = dict(args=[ffmpeg input args], rec=bool)   (panels always go on the stream)
    """
    fps, q = int(o["fps"]), QUALITY[o["quality"]]
    a = [ff, "-hide_banner", "-nostats", "-loglevel", "warning", "-y"]
    if stream:
        a += ["-progress", "pipe:1", "-stats_period", "2"]
    if use_dd:
        a += ["-f", "lavfi", "-i",
              f"ddagrab=output_idx={monitor['index']}:framerate={fps}:draw_mouse={int(o['cursor'])},hwdownload,format=bgra"]
    else:
        a += ["-f", "gdigrab", "-framerate", str(fps), "-draw_mouse", str(int(o["cursor"])),
              "-offset_x", str(monitor["x"]), "-offset_y", str(monitor["y"]),
              "-video_size", f"{monitor['w']}x{monitor['h']}", "-i", "desktop"]
    for dev in o["audio"]:
        a += ["-f", "dshow", "-thread_queue_size", "1024", "-audio_buffer_size", "80",
              "-use_wallclock_as_timestamps", "1", "-i", f"audio={dev}"]
    n_audio = len(o["audio"])
    if stream and not n_audio:  # platforms like an audio track to exist; give them silence
        a += ["-f", "lavfi", "-i", "anullsrc=channel_layout=stereo:sample_rate=48000"]
        n_audio = 1
    ov_idx = 1 + n_audio
    if overlay:
        a += overlay["args"]

    pix = "yuv420p" if enc == "libx264" else "nv12"
    branches = []  # (key, size, extra filters before scale, scale flags, overlay?)
    if rec_out:
        branches.append(("rec", out_size(monitor, o["resolution"]), "", "lanczos", bool(overlay and overlay["rec"])))
    if stream:
        branches.append(("str", out_size(monitor, stream["resolution"]), f"fps={int(stream['fps'])},", "bicubic",
                         bool(overlay)))
    parts = []
    k = len(branches)
    srcs = {b[0]: "[0:v]" for b in branches}
    if k > 1:
        parts.append("[0:v]split=%d%s" % (k, "".join(f"[s_{b[0]}]" for b in branches)))
        srcs = {b[0]: f"[s_{b[0]}]" for b in branches}
    ovl_users = [b[0] for b in branches if b[4]]
    ovl_src = {u: f"[{ov_idx}:v]" for u in ovl_users}
    if len(ovl_users) > 1:
        parts.append(f"[{ov_idx}:v]split={len(ovl_users)}" + "".join(f"[o_{u}]" for u in ovl_users))
        ovl_src = {u: f"[o_{u}]" for u in ovl_users}
    for key, (w, h), pre, flags, use_ov in branches:
        if use_ov:
            parts.append(f"{srcs[key]}{pre}scale={w}:{h}:flags={flags}[b_{key}]")
            parts.append(f"{ovl_src[key]}scale={w}:{h}:flags=bilinear[ov_{key}]")
            parts.append(f"[b_{key}][ov_{key}]overlay=0:0:format=auto:eof_action=repeat,"
                         f"scale=iw:ih:out_color_matrix=bt709:out_range=tv,format={pix}[v_{key}]")
        else:
            parts.append(f"{srcs[key]}{pre}scale={w}:{h}:flags={flags}:out_color_matrix=bt709:out_range=tv,"
                         f"format={pix}[v_{key}]")

    audio_lbl = {}
    if n_audio:
        mp, labels = o.get("ptt_pos"), []
        for i in range(n_audio):
            if i == mp:
                parts.append(f"[{i + 1}:a]volume=0[a{i}]")
                labels.append(f"[a{i}]")
            else:
                labels.append(f"[{i + 1}:a]")
        tail = "amix=inputs=2:duration=longest:normalize=0," if n_audio == 2 else ""
        if k > 1:
            parts.append("".join(labels) + tail + "aresample=async=1:first_pts=0,asplit=%d%s" %
                         (k, "".join(f"[a_{b[0]}]" for b in branches)))
            audio_lbl = {b[0]: f"[a_{b[0]}]" for b in branches}
        else:
            parts.append("".join(labels) + tail + f"aresample=async=1:first_pts=0[a_{branches[0][0]}]")
            audio_lbl = {branches[0][0]: f"[a_{branches[0][0]}]"}
    a += ["-filter_complex", ";".join(parts)]

    if rec_out:
        a += ["-map", "[v_rec]"] + (["-map", audio_lbl["rec"]] if n_audio else [])
        a += encoder_args(enc, o["quality"])
        a += ["-g", str(fps * 2), "-colorspace", "bt709", "-color_primaries", "bt709",
              "-color_trc", "bt709", "-color_range", "tv"]
        if n_audio:
            a += ["-c:a", "aac", "-b:a", q["ab"], "-ar", "48000"]
        a.append(rec_out)
    if stream:
        sf = int(stream["fps"])
        a += ["-map", "[v_str]"] + (["-map", audio_lbl["str"]] if n_audio else [])
        a += stream_encoder_args(enc, int(stream["bitrate"]))
        a += ["-g", str(sf * 2), "-colorspace", "bt709", "-color_primaries", "bt709",
              "-color_trc", "bt709", "-color_range", "tv"]
        if n_audio:
            a += ["-c:a", "aac", "-b:a", "160k", "-ar", "48000", "-ac", "2"]
        urls = stream["urls"]
        if len(urls) == 1:
            a += ["-f", "flv", urls[0]]
        else:  # one encode, several destinations; a failed one doesn't stop the others
            a += ["-f", "tee", "|".join(f"[f=flv:onfail=ignore]{u}" for u in urls)]
    return a


# --------------------------------------------------------------------------- finishing job
class FinalizeWorker(QThread):
    done = Signal(str, list)  # final path, list of warnings
    failed = Signal(str)

    def __init__(self, ff, tmp, final, copy_dirs, keep_mkv):
        super().__init__()
        self.ff, self.tmp, self.final = ff, tmp, final
        self.copy_dirs, self.keep_mkv = copy_dirs, keep_mkv

    def run(self):
        warnings = []
        try:
            if not os.path.exists(self.tmp) or os.path.getsize(self.tmp) < 2048:
                raise RuntimeError("No video was captured.")
            result = self.final
            try:
                r = _run([self.ff, "-y", "-hide_banner", "-loglevel", "error", "-i", self.tmp,
                          "-c", "copy", "-movflags", "+faststart", self.final], timeout=600)
                if r.returncode != 0 or not os.path.exists(self.final):
                    raise RuntimeError(r.stderr)
                if not self.keep_mkv:
                    os.remove(self.tmp)
            except Exception:
                result = self.tmp
                warnings.append("Couldn't convert to MP4, so the MKV was kept.")
            for d in self.copy_dirs:
                try:
                    Path(d).mkdir(parents=True, exist_ok=True)
                    shutil.copy2(result, d)
                except Exception as e:
                    warnings.append(f"Couldn't copy to {d}: {e}")
            self.done.emit(result, warnings)
        except Exception as e:
            self.failed.emit(str(e))


# --------------------------------------------------------------------------- recorder
class Recorder(QObject):
    started = Signal()
    processing = Signal()
    finished = Signal(str, list)
    failed = Signal(str)
    line = Signal(str)
    stats = Signal(dict)
    _exited = Signal(int, str)

    def __init__(self, ff):
        super().__init__()
        self.ff = ff
        self.proc = None
        self.secrets, self.record = [], True
        self.t0 = 0.0
        self._stopping = False
        self._job = None
        self._exited.connect(self._on_exit)

    @property
    def active(self):
        return self.proc is not None and self.proc.poll() is None

    def elapsed(self):
        return time.time() - self.t0 if self.active else 0

    def mask(self, text):
        for secret in self.secrets:
            if secret:
                text = text.replace(secret, "****")
        return text

    def start(self, args, tmp, final, copy_dirs, keep_mkv, record=True, secrets=()):
        self.tmp, self.final, self.copy_dirs, self.keep_mkv = tmp, final, copy_dirs, keep_mkv
        self.record, self.secrets = record, list(secrets)
        self._stopping = False
        self.proc = subprocess.Popen(args, stdin=subprocess.PIPE, stdout=subprocess.PIPE,
                                     stderr=subprocess.STDOUT, creationflags=NO_WINDOW)
        self.t0 = time.time()
        threading.Thread(target=self._reader, args=(self.proc,), daemon=True).start()
        self.started.emit()

    def _reader(self, proc):
        tail, cur = collections.deque(maxlen=25), {}
        for raw in iter(proc.stdout.readline, b""):
            text = raw.decode("utf-8", "replace").rstrip()
            m = re.match(r"^(bitrate|fps|drop_frames|dup_frames|speed|total_size|out_time|out_time_us|out_time_ms|"
                         r"frame|progress|stream_\d+_\d+_q)=(.*)$", text)
            if m:
                cur[m[1]] = m[2].strip()
                if m[1] == "progress":
                    self.stats.emit(dict(cur))
                    cur = {}
            elif text:
                text = self.mask(text)
                tail.append(text)
                self.line.emit(text)
        self._exited.emit(proc.wait(), "\n".join(tail))

    def send(self, line):
        """Send a live command to FFmpeg's filters (used by push-to-talk)."""
        if self.active and not self._stopping:
            try:
                self.proc.stdin.write(f"c{line}\n".encode())
                self.proc.stdin.flush()
            except Exception:
                pass

    def stop(self):
        if not self.active:
            return
        self._stopping = True
        try:
            self.proc.stdin.write(b"q")
            self.proc.stdin.flush()
        except Exception:
            pass
        QTimer.singleShot(15000, self._force)

    def _force(self):
        if self.proc and self.proc.poll() is None:
            self.proc.terminate()

    def _on_exit(self, code, log):
        if not self._stopping:
            self.failed.emit(log or f"FFmpeg stopped unexpectedly (exit code {code}).")
            return
        if not self.record:
            self.finished.emit("", [])
            return
        self.processing.emit()
        self._job = FinalizeWorker(self.ff, self.tmp, self.final, self.copy_dirs, self.keep_mkv)
        self._job.done.connect(self.finished.emit)
        self._job.failed.connect(self.failed.emit)
        self._job.start()
