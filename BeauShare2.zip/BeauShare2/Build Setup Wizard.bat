@echo off
setlocal EnableExtensions
title BeauShare setup wizard builder
cd /d "%~dp0"
echo.
echo  Building BeauShareSetup.exe (first run takes 5-10 minutes)
echo.
call "%~dp0build_app.bat"
if errorlevel 2 goto :restart
if errorlevel 1 goto :fail

echo.
echo Looking for Inno Setup...
call :findiscc
if defined ISCC goto :compile
echo Installing Inno Setup with winget...
winget install -e --id JRSoftware.InnoSetup --accept-source-agreements --accept-package-agreements
call :findiscc
if not defined ISCC goto :noinno

:compile
echo.
echo Creating the setup wizard...
"%ISCC%" "%~dp0BeauShare.iss"
if errorlevel 1 goto :fail
echo.
echo  Done! Your installer is: %~dp0Output\BeauShareSetup.exe
echo  Send that one file to people. They double-click it and follow the wizard.
explorer "%~dp0Output"
pause
exit /b 0

:findiscc
set "ISCC="
if exist "%ProgramFiles(x86)%\Inno Setup 6\ISCC.exe" set "ISCC=%ProgramFiles(x86)%\Inno Setup 6\ISCC.exe"
if exist "%ProgramFiles%\Inno Setup 6\ISCC.exe" set "ISCC=%ProgramFiles%\Inno Setup 6\ISCC.exe"
if exist "%LOCALAPPDATA%\Programs\Inno Setup 6\ISCC.exe" set "ISCC=%LOCALAPPDATA%\Programs\Inno Setup 6\ISCC.exe"
exit /b 0

:noinno
echo.
echo Couldn't install Inno Setup automatically. Download it free from https://jrsoftware.org/isdl.php
echo install it, then run this file again.
pause
exit /b 1

:restart
echo.
echo Python is installed. Please CLOSE this window and run this file again.
pause
exit /b 1

:fail
echo.
echo Something went wrong. Scroll up to see the error, and send it to me if you're stuck.
pause
exit /b 1
