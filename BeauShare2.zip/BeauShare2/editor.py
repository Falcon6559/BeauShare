"""BeauShare editor: preview, mark start/end, build a clip list, export (separate or joined)."""
import collections
import os
import re
import shutil
import subprocess
import tempfile
from pathlib import Path

from PySide6.QtCore import QPointF, QRectF, Qt, QThread, QUrl, Signal
from PySide6.QtGui import QColor, QKeySequence, QPainter, QPen, QPolygonF, QShortcut
from PySide6.QtMultimedia import QAudioOutput, QMediaPlayer
from PySide6.QtMultimediaWidgets import QVideoWidget
from PySide6.QtWidgets import (QComboBox, QFileDialog, QHBoxLayout, QListWidget, QMessageBox, QProgressBar,
                               QPushButton, QStackedWidget, QVBoxLayout, QWidget)

import engine
from theme import LILAC, LINE, PANEL, TALLY, fmt_ms, label, reveal


# --------------------------------------------------------------------------- timeline widget
class Timeline(QWidget):
    seek = Signal(int)
    range_changed = Signal(int, int)

    PAD = 12

    def __init__(self):
        super().__init__()
        self.setMinimumHeight(76)
        self.dur, self.pos, self.a, self.b = 1, 0, 0, 1
        self.clips, self.drag = [], None

    def _x(self, ms):
        return self.PAD + (self.width() - 2 * self.PAD) * ms / max(1, self.dur)

    def _ms(self, x):
        return int(max(0, min(self.dur, (x - self.PAD) / max(1, self.width() - 2 * self.PAD) * self.dur)))

    def set_range(self, a, b):
        self.a, self.b = a, b
        self.update()

    def paintEvent(self, _):
        p = QPainter(self)
        p.setRenderHint(QPainter.Antialiasing)
        top, h = 26, 34
        p.setPen(QPen(QColor(LINE), 1))
        p.setBrush(QColor(PANEL))
        p.drawRoundedRect(QRectF(self.PAD, top, self.width() - 2 * self.PAD, h), 6, 6)
        p.setPen(Qt.NoPen)
        p.setBrush(QColor(179, 166, 255, 55))
        for a, b in self.clips:
            p.drawRect(QRectF(self._x(a), top + 1, self._x(b) - self._x(a), h - 2))
        xa, xb = self._x(self.a), self._x(self.b)
        p.setBrush(QColor(179, 166, 255, 120))
        p.drawRect(QRectF(xa, top, xb - xa, h))
        p.setBrush(QColor(LILAC))
        for x in (xa, xb):
            p.drawRoundedRect(QRectF(x - 4, top - 3, 8, h + 6), 3, 3)
        x = self._x(self.pos)
        p.setPen(QPen(QColor(TALLY), 2))
        p.drawLine(QPointF(x, top - 8), QPointF(x, top + h + 6))
        p.setPen(Qt.NoPen)
        p.setBrush(QColor(TALLY))
        p.drawPolygon(QPolygonF([QPointF(x - 6, top - 14), QPointF(x + 6, top - 14), QPointF(x, top - 4)]))

    def mousePressEvent(self, e):
        x = e.position().x()
        if abs(x - self._x(self.a)) <= 8:
            self.drag = "a"
        elif abs(x - self._x(self.b)) <= 8:
            self.drag = "b"
        else:
            self.drag = "seek"
        self.mouseMoveEvent(e)

    def mouseMoveEvent(self, e):
        if not self.drag:
            return
        ms = self._ms(e.position().x())
        if self.drag == "a":
            self.a = min(ms, self.b - 100)
            self.range_changed.emit(self.a, self.b)
        elif self.drag == "b":
            self.b = max(ms, self.a + 100)
            self.range_changed.emit(self.a, self.b)
        self.seek.emit(ms)
        self.update()

    def mouseReleaseEvent(self, _):
        self.drag = None


# --------------------------------------------------------------------------- export
class ExportWorker(QThread):
    progress = Signal(int)
    done = Signal(list, list)
    failed = Signal(str)

    def __init__(self, ff, src, clips, join, precise, enc, quality, has_audio, copy_dirs):
        super().__init__()
        self.ff, self.src, self.clips, self.join = ff, src, clips, join
        self.precise, self.enc, self.quality = precise, enc, quality
        self.has_audio, self.copy_dirs = has_audio, copy_dirs
        self.tmp_files = []

    @staticmethod
    def unique(p):
        p, n = Path(p), 2
        q = p
        while q.exists():
            q = p.with_name(f"{p.stem}_{n}{p.suffix}")
            n += 1
        return str(q)

    def encode_args(self):
        pix = "yuv420p" if self.enc == "libx264" else "nv12"
        a = engine.encoder_args(self.enc, self.quality) + ["-pix_fmt", pix, "-g", "120"]
        if self.has_audio:
            a += ["-c:a", "aac", "-b:a", "192k"]
        return a + ["-movflags", "+faststart"]

    def plan(self):
        base, outdir = Path(self.src).stem, Path(self.src).parent
        head = [self.ff, "-y", "-hide_banner", "-loglevel", "error", "-nostats", "-progress", "pipe:1"]
        seg = lambda a, b: ["-ss", f"{a / 1000:.3f}", "-to", f"{b / 1000:.3f}"]
        jobs = []
        if not self.join or len(self.clips) == 1:
            for i, (a, b) in enumerate(self.clips, 1):
                out = self.unique(outdir / (f"{base}_clip{i}.mp4" if len(self.clips) > 1 else f"{base}_clip.mp4"))
                if self.precise:
                    cmd = head + seg(a, b) + ["-i", self.src, "-map", "0:v:0"]
                    cmd += ["-map", "0:a:0"] if self.has_audio else []
                    cmd += self.encode_args() + [out]
                else:
                    cmd = head + seg(a, b) + ["-i", self.src, "-map", "0", "-c", "copy",
                                              "-avoid_negative_ts", "make_zero", "-movflags", "+faststart", out]
                jobs.append((cmd, (b - a) / 1000, out))
            return jobs
        out = self.unique(outdir / f"{base}_edit.mp4")
        total = sum(b - a for a, b in self.clips) / 1000
        if self.precise:
            cmd = list(head)
            for a, b in self.clips:
                cmd += seg(a, b) + ["-i", self.src]
            n = len(self.clips)
            if self.has_audio:
                ins = "".join(f"[{i}:v:0][{i}:a:0]" for i in range(n))
                cmd += ["-filter_complex", f"{ins}concat=n={n}:v=1:a=1[v][a]", "-map", "[v]", "-map", "[a]"]
            else:
                ins = "".join(f"[{i}:v:0]" for i in range(n))
                cmd += ["-filter_complex", f"{ins}concat=n={n}:v=1:a=0[v]", "-map", "[v]"]
            cmd += self.encode_args() + [out]
        else:
            lst = tempfile.NamedTemporaryFile("w", suffix=".txt", delete=False, encoding="utf-8")
            src = self.src.replace("\\", "/").replace("'", "'\\''")
            for a, b in self.clips:
                lst.write(f"file '{src}'\ninpoint {a / 1000:.3f}\noutpoint {b / 1000:.3f}\n")
            lst.close()
            self.tmp_files.append(lst.name)
            cmd = head + ["-f", "concat", "-safe", "0", "-i", lst.name, "-c", "copy",
                          "-movflags", "+faststart", out]
        return [(cmd, total, out)]

    def run_job(self, cmd, secs, done_s, total, out):
        p = subprocess.Popen(cmd, stdout=subprocess.PIPE, stderr=subprocess.STDOUT, text=True,
                             encoding="utf-8", errors="replace", creationflags=engine.NO_WINDOW)
        tail = collections.deque(maxlen=12)
        for line in p.stdout:
            line = line.strip()
            if line.startswith(("out_time_us=", "out_time_ms=")):
                try:
                    cur = int(line.split("=")[1]) / 1e6
                    self.progress.emit(int(100 * min(total, done_s + max(0.0, cur)) / total))
                except ValueError:
                    pass
            elif line and not re.match(r"^[a-z_0-9]+=", line):
                tail.append(line)
        if p.wait() != 0 or not os.path.exists(out):
            raise RuntimeError("\n".join(tail) or "FFmpeg couldn't export this clip.")

    def run(self):
        try:
            jobs = self.plan()
            total = sum(j[1] for j in jobs) or 1
            done_s, outs, warns = 0.0, [], []
            for cmd, secs, out in jobs:
                self.run_job(cmd, secs, done_s, total, out)
                done_s += secs
                outs.append(out)
            for d in self.copy_dirs:
                for o in outs:
                    try:
                        Path(d).mkdir(parents=True, exist_ok=True)
                        shutil.copy2(o, d)
                    except Exception as e:
                        warns.append(f"Couldn't copy to {d}: {e}")
            self.progress.emit(100)
            self.done.emit(outs, warns)
        except Exception as e:
            self.failed.emit(str(e))
        finally:
            for f in self.tmp_files:
                try:
                    os.remove(f)
                except OSError:
                    pass


# --------------------------------------------------------------------------- editor page
class EditorPage(QWidget):
    def __init__(self, main):
        super().__init__()
        self.setObjectName("Page")
        self.m = main
        self.path, self.fps, self.has_audio = None, 30.0, True
        self.clips, self.play_until, self.worker, self.fresh = [], None, None, False

        self.player = QMediaPlayer(self)
        self.audio = QAudioOutput(self)
        self.player.setAudioOutput(self.audio)
        self.video = QVideoWidget()
        self.video.setMinimumHeight(220)
        self.video.setStyleSheet("background: #000;")
        self.player.setVideoOutput(self.video)
        self.player.positionChanged.connect(self.on_position)
        self.player.durationChanged.connect(self.on_duration)
        self.player.errorOccurred.connect(lambda *_: self.info.setText(
            "This file can't be previewed here. Recordings saved as MP4 work best."))

        lay = QVBoxLayout(self)
        lay.setContentsMargins(28, 24, 28, 20)
        lay.setSpacing(10)
        top = QHBoxLayout()
        top.addWidget(label("Editor", "Brand"))
        self.name = label("", "Muted")
        top.addWidget(self.name, 1)
        open_btn = QPushButton("Open video…")
        open_btn.clicked.connect(self.open_dialog)
        top.addWidget(open_btn)
        lay.addLayout(top)

        self.view = QStackedWidget()
        empty = label("Open a recording to start editing. Use Edit in the Library, or the button above.", "Muted")
        empty.setAlignment(Qt.AlignCenter)
        self.view.addWidget(empty)
        self.view.addWidget(self.video)
        lay.addWidget(self.view, 1)

        row = QHBoxLayout()
        self.play_btn = QPushButton("Play")
        self.play_btn.clicked.connect(self.toggle_play)
        self.sel_btn = QPushButton("Play selection")
        self.sel_btn.clicked.connect(self.play_selection)
        self.time = label("0:00.0 / 0:00.0", "Muted")
        row.addWidget(self.play_btn)
        row.addWidget(self.sel_btn)
        row.addWidget(self.time)
        row.addStretch()
        for text, fn in (("Set start", self.set_start), ("Set end", self.set_end)):
            b = QPushButton(text)
            b.clicked.connect(fn)
            row.addWidget(b)
        add = QPushButton("Add clip")
        add.setObjectName("Go")
        add.clicked.connect(self.add_clip)
        row.addWidget(add)
        lay.addLayout(row)

        self.timeline = Timeline()
        self.timeline.seek.connect(self.player.setPosition)
        self.timeline.range_changed.connect(lambda *_: self.update_info())
        lay.addWidget(self.timeline)
        self.info = label("Space plays or pauses. I and O set the start and end. Arrow keys step 1 second; "
                          "hold Shift to step one frame.", "Hint")
        lay.addWidget(self.info)

        bottom = QHBoxLayout()
        bottom.setSpacing(18)
        left = QVBoxLayout()
        left.addWidget(label("Clips", "H"))
        self.list = QListWidget()
        self.list.setFixedHeight(120)
        self.list.itemSelectionChanged.connect(self.select_clip)
        left.addWidget(self.list)
        lrow = QHBoxLayout()
        for text, fn in (("Update", self.update_clip), ("Remove", self.remove_clip),
                         ("Up", lambda: self.move_clip(-1)), ("Down", lambda: self.move_clip(1))):
            b = QPushButton(text)
            b.clicked.connect(fn)
            lrow.addWidget(b)
        lrow.addStretch()
        left.addLayout(lrow)
        bottom.addLayout(left, 3)

        right = QVBoxLayout()
        right.addWidget(label("Export", "H"))
        self.out_mode = QComboBox()
        self.out_mode.addItems(["Separate files", "Join into one video"])
        self.method = QComboBox()
        self.method.addItems(["Accurate (re-encodes)", "Fast (no re-encode, cuts at keyframes)"])
        self.export_btn = QPushButton("Export")
        self.export_btn.setObjectName("Go")
        self.export_btn.clicked.connect(self.export)
        self.bar = QProgressBar()
        self.bar.hide()
        for w in (self.out_mode, self.method, self.export_btn, self.bar):
            right.addWidget(w)
        right.addStretch()
        bottom.addLayout(right, 2)
        lay.addLayout(bottom)

        for b in self.findChildren(QPushButton):
            b.setFocusPolicy(Qt.NoFocus)
        ctx = Qt.WidgetWithChildrenShortcut
        for key, fn in (("Space", self.toggle_play), ("I", self.set_start), ("O", self.set_end),
                        ("Left", lambda: self.step(-1000)), ("Right", lambda: self.step(1000)),
                        ("Shift+Left", lambda: self.step(-self.frame_ms())),
                        ("Shift+Right", lambda: self.step(self.frame_ms()))):
            QShortcut(QKeySequence(key), self, activated=fn, context=ctx)

    # ---- loading / transport
    def open_dialog(self):
        f, _ = QFileDialog.getOpenFileName(self, "Open video", self.m.s["save_dir"],
                                           "Video (*.mp4 *.mkv *.mov *.webm)")
        if f:
            self.load(f)

    def load(self, path):
        if not self.m.ff:
            QMessageBox.information(self, "BeauShare", "FFmpeg is needed for editing. Install it from the Record page.")
            return
        info = engine.probe_media(self.m.ff, path)
        self.path, self.fps, self.has_audio = path, max(1.0, info["fps"]), info["audio"]
        self.clips, self.fresh = [], True
        self.name.setText(Path(path).name)
        self.list.clear()
        dur = int(info["duration"] * 1000) or 1
        self.timeline.dur, self.timeline.pos, self.timeline.clips = dur, 0, []
        self.timeline.set_range(0, dur)
        self.player.setSource(QUrl.fromLocalFile(path))
        self.player.pause()
        self.view.setCurrentIndex(1)
        self.update_info()

    def frame_ms(self):
        return max(1, int(1000 / self.fps))

    def on_duration(self, ms):
        if ms > 0:
            self.timeline.dur = ms
            if self.fresh:
                self.timeline.set_range(0, ms)
                self.fresh = False
            self.update_info()

    def on_position(self, ms):
        self.timeline.pos = ms
        self.timeline.update()
        self.time.setText(f"{fmt_ms(ms)} / {fmt_ms(self.timeline.dur)}")
        if self.play_until is not None and ms >= self.play_until:
            self.player.pause()
            self.play_until = None
        self.play_btn.setText("Pause" if self.player.isPlaying() else "Play")

    def toggle_play(self):
        if not self.path:
            return
        self.play_until = None
        if self.player.isPlaying():
            self.player.pause()
        else:
            self.player.play()
        self.play_btn.setText("Pause" if self.player.isPlaying() else "Play")

    def play_selection(self):
        if self.path:
            self.play_until = self.timeline.b
            self.player.setPosition(self.timeline.a)
            self.player.play()

    def step(self, delta):
        if self.path:
            self.player.pause()
            self.player.setPosition(max(0, min(self.timeline.dur, self.player.position() + delta)))

    # ---- marking and clips
    def set_start(self):
        t = self.timeline
        t.set_range(min(self.player.position(), t.b - 100), t.b)
        self.update_info()

    def set_end(self):
        t = self.timeline
        t.set_range(t.a, max(self.player.position(), t.a + 100))
        self.update_info()

    def update_info(self):
        t = self.timeline
        self.info.setText(f"Selection {fmt_ms(t.a)} to {fmt_ms(t.b)}  ({(t.b - t.a) / 1000:.1f} s)")

    def refresh_list(self, select=None):
        self.list.blockSignals(True)
        self.list.clear()
        for i, (a, b) in enumerate(self.clips, 1):
            self.list.addItem(f"Clip {i}    {fmt_ms(a)} to {fmt_ms(b)}    ({(b - a) / 1000:.1f} s)")
        if select is not None and 0 <= select < len(self.clips):
            self.list.setCurrentRow(select)
        self.list.blockSignals(False)
        self.timeline.clips = list(self.clips)
        self.timeline.update()

    def add_clip(self):
        t = self.timeline
        if self.path and t.b - t.a >= 100:
            self.clips.append((t.a, t.b))
            self.refresh_list(len(self.clips) - 1)

    def select_clip(self):
        r = self.list.currentRow()
        if 0 <= r < len(self.clips):
            a, b = self.clips[r]
            self.timeline.set_range(a, b)
            self.player.setPosition(a)
            self.update_info()

    def update_clip(self):
        r = self.list.currentRow()
        if 0 <= r < len(self.clips):
            self.clips[r] = (self.timeline.a, self.timeline.b)
            self.refresh_list(r)

    def remove_clip(self):
        r = self.list.currentRow()
        if 0 <= r < len(self.clips):
            self.clips.pop(r)
            self.refresh_list(min(r, len(self.clips) - 1))

    def move_clip(self, d):
        r = self.list.currentRow()
        if 0 <= r < len(self.clips) and 0 <= r + d < len(self.clips):
            self.clips[r], self.clips[r + d] = self.clips[r + d], self.clips[r]
            self.refresh_list(r + d)

    # ---- export
    def export(self):
        if not self.path:
            return
        clips = list(self.clips)
        if not clips:  # nothing added yet: export the current selection
            t = self.timeline
            if t.b - t.a < 100:
                return
            clips = [(t.a, t.b)]
        self.player.pause()
        self.export_btn.setEnabled(False)
        self.bar.setValue(0)
        self.bar.show()
        self.worker = ExportWorker(self.m.ff, self.path, clips, self.out_mode.currentIndex() == 1,
                                   self.method.currentIndex() == 0, self.m.chosen_encoder(),
                                   self.m.quality.currentText(), self.has_audio, self.m.s["copy_dirs"])
        self.worker.progress.connect(self.bar.setValue)
        self.worker.done.connect(self.exported)
        self.worker.failed.connect(self.export_failed)
        self.worker.start()

    def export_failed(self, msg):
        self.export_btn.setEnabled(True)
        self.bar.hide()
        QMessageBox.critical(self, "Export failed", msg[-800:])

    def exported(self, outs, warns):
        self.export_btn.setEnabled(True)
        self.bar.hide()
        self.m.refresh_library()
        box = QMessageBox(self)
        box.setWindowTitle("Export finished")
        text = f"Saved {len(outs)} file{'s' if len(outs) != 1 else ''} to {Path(outs[0]).parent}"
        box.setText(text + ("\n\n" + "\n".join(warns) if warns else ""))
        show = box.addButton("Show in folder", QMessageBox.ActionRole)
        up = box.addButton("Upload to YouTube", QMessageBox.ActionRole) if len(outs) == 1 else None
        box.addButton("Close", QMessageBox.RejectRole)
        box.exec()
        if box.clickedButton() is show:
            reveal(outs[0])
        elif up is not None and box.clickedButton() is up:
            self.m.upload(outs[0])
