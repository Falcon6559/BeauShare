@echo off
cd /d "%~dp0"
where python >nul 2>nul || (echo Python 3.10+ is required. Install it from python.org or the Microsoft Store. & pause & exit /b 1)
if not exist .venv ( python -m venv .venv )
call .venv\Scripts\activate
pip install -q -r requirements.txt
start "" pythonw beaushare.py
